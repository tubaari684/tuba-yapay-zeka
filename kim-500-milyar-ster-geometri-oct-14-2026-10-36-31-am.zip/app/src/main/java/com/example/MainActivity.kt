package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.ui.screens.GuideScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.screens.StartScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.StudioNavyDark
import com.example.viewmodel.QuizViewModel

enum class AppScreen {
    START,
    QUIZ,
    GUIDE
}

class MainActivity : ComponentActivity() {

    private val quizViewModel: QuizViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                Scaffold(
                    contentWindowInsets = WindowInsets.safeDrawing,
                    containerColor = StudioNavyDark,
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    MainNavigation(
                        viewModel = quizViewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun MainNavigation(
    viewModel: QuizViewModel,
    modifier: Modifier = Modifier
) {
    var currentScreen by remember { mutableStateOf(AppScreen.START) }
    val uiState by viewModel.uiState.collectAsState()

    when (currentScreen) {
        AppScreen.START -> {
            StartScreen(
                stats = uiState.stats,
                onStartGame = {
                    viewModel.startNewGame()
                    currentScreen = AppScreen.QUIZ
                },
                onOpenGuide = {
                    currentScreen = AppScreen.GUIDE
                },
                onToggleSound = { viewModel.toggleSound(it) },
                onToggleVibration = { viewModel.toggleVibration(it) },
                modifier = modifier
            )
        }
        AppScreen.QUIZ -> {
            QuizScreen(
                viewModel = viewModel,
                onNavigateBack = {
                    viewModel.loadStats()
                    currentScreen = AppScreen.START
                },
                onOpenGuide = {
                    currentScreen = AppScreen.GUIDE
                },
                modifier = modifier
            )
        }
        AppScreen.GUIDE -> {
            GuideScreen(
                onNavigateBack = {
                    currentScreen = AppScreen.START
                },
                modifier = modifier
            )
        }
    }
}
