package com.example.model

enum class GeometryTopic(val displayName: String) {
    NOKTA_DOGRU_ISIN("Temel Kavramlar (Nokta, Doğru, Işın)"),
    DOGRU_KONUMLARI("Doğruların Konumları"),
    ACILAR("Açılar ve Çeşitleri"),
    UCGENLER_DORTGENLER("Üçgenler ve Dörtgenler")
}

enum class DiagramType {
    NONE,
    LINE,                // İki ucu oklu doğru
    RAY,                 // Bir ucu kapalı, bir ucu oklu ışın
    LINE_SEGMENT,        // İki ucu noktalı doğru parçası
    PARALLEL_LINES,      // Paralel iki doğru (d // k)
    PERPENDICULAR_LINES, // Dik kesişen doğrular (90° sembolü)
    INTERSECTING_LINES,  // Kesişen iki doğru
    ACUTE_ANGLE,         // Dar açı (<90°)
    RIGHT_ANGLE,         // Dik açı (90°)
    OBTUSE_ANGLE,        // Geniş açı (>90°)
    STRAIGHT_ANGLE,      // Doğru açı (180°)
    CLOCK_TIME,          // Saat kadranı (akrep ve yelkovan)
    TRIANGLE_ANGLES,     // Üçgen iç açıları
    QUADRILATERAL        // Dörtgen çizimi
}

data class DiagramData(
    val type: DiagramType,
    val angleDegree: Float = 0f,
    val labelA: String = "A",
    val labelB: String = "B",
    val labelC: String = "C",
    val labelExtra: String = "",
    val clockHour: Int = 3,
    val clockMinute: Int = 0,
    val knownAngle1: Int = 0,
    val knownAngle2: Int = 0,
    val missingAngle: Boolean = true
)

data class Question(
    val id: Int,
    val level: Int, // 1 to 12
    val questionText: String,
    val options: List<String>, // size = 4: [A, B, C, D]
    val correctIndex: Int, // 0..3
    val topic: GeometryTopic,
    val explanation: String,
    val diagramData: DiagramData? = null
)

data class PrizeStep(
    val level: Int,
    val prizeAmount: Long,
    val displayAmount: String,
    val isCheckpoint: Boolean = false // Baraj sorusu
)

enum class LifelineType {
    FIFTY_FIFTY,     // %50 Yarı Yarıya
    PHONE_FRIEND,    // Telefon Jokeri
    ASK_AUDIENCE,    // Seyirciye Sor
    SWAP_QUESTION    // Soru Değiştir
}

data class LifelinesState(
    val fiftyFiftyUsed: Boolean = false,
    val phoneFriendUsed: Boolean = false,
    val askAudienceUsed: Boolean = false,
    val swapQuestionUsed: Boolean = false
)

enum class PhoneFriendCharacter(
    val personName: String,
    val title: String,
    val description: String,
    val baseAccuracy: Float
) {
    MATH_TEACHER(
        personName = "Ali Öğretmen",
        title = "5. Sınıf Matematik Öğretmeni",
        description = "Müfredata çok hakim, gerekçeli net bilgi verir.",
        baseAccuracy = 0.92f
    ),
    HONOR_STUDENT(
        personName = "Zeynep",
        title = "Sınıf Birincisi",
        description = "Geometri ünitesini dün tekrar etti.",
        baseAccuracy = 0.86f
    ),
    ENGINEER_UNCLE(
        personName = "Selim Bey",
        title = "İnşaat Mühendisi",
        description = "Projeler ve çizimlerle arası çok iyidir.",
        baseAccuracy = 0.80f
    )
}

data class PhoneResponse(
    val character: PhoneFriendCharacter,
    val suggestedOptionIndex: Int,
    val confidencePercent: Int,
    val message: String
)

data class AudienceVoteResult(
    val percentages: List<Int> // Size 4, sums to 100
)

enum class ActiveModal {
    NONE,
    MONEY_LADDER,
    PHONE_FRIEND_SELECT,
    PHONE_FRIEND_RESULT,
    AUDIENCE_POLL,
    CONFIRM_WALKAWAY,
    EXPLANATION_CARD
}
