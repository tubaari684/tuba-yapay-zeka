package com.example.util

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SoundHapticManager(private val context: Context) {

    private var toneGenerator: ToneGenerator? = null
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val scope = CoroutineScope(Dispatchers.Default)

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
        } catch (_: Exception) {
            toneGenerator = null
        }
    }

    fun playSelect(soundEnabled: Boolean = true, vibrationEnabled: Boolean = true) {
        if (vibrationEnabled) vibrate(40)
        if (soundEnabled) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
            } catch (_: Exception) {}
        }
    }

    fun playLockIn(soundEnabled: Boolean = true, vibrationEnabled: Boolean = true) {
        if (vibrationEnabled) vibrate(100)
        if (soundEnabled) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 200)
            } catch (_: Exception) {}
        }
    }

    fun playCorrect(soundEnabled: Boolean = true, vibrationEnabled: Boolean = true) {
        if (vibrationEnabled) {
            vibratePattern(longArrayOf(0, 80, 60, 150))
        }
        if (soundEnabled) {
            scope.launch {
                try {
                    toneGenerator?.startTone(ToneGenerator.TONE_DTMF_3, 120)
                    delay(120)
                    toneGenerator?.startTone(ToneGenerator.TONE_DTMF_6, 120)
                    delay(120)
                    toneGenerator?.startTone(ToneGenerator.TONE_DTMF_9, 250)
                } catch (_: Exception) {}
            }
        }
    }

    fun playWrong(soundEnabled: Boolean = true, vibrationEnabled: Boolean = true) {
        if (vibrationEnabled) {
            vibratePattern(longArrayOf(0, 200, 100, 300))
        }
        if (soundEnabled) {
            scope.launch {
                try {
                    toneGenerator?.startTone(ToneGenerator.TONE_CDMA_SOFT_ERROR_LITE, 350)
                } catch (_: Exception) {}
            }
        }
    }

    fun playLifeline(soundEnabled: Boolean = true, vibrationEnabled: Boolean = true) {
        if (vibrationEnabled) vibrate(60)
        if (soundEnabled) {
            scope.launch {
                try {
                    toneGenerator?.startTone(ToneGenerator.TONE_DTMF_1, 90)
                    delay(90)
                    toneGenerator?.startTone(ToneGenerator.TONE_DTMF_5, 120)
                } catch (_: Exception) {}
            }
        }
    }

    fun playVictory(soundEnabled: Boolean = true, vibrationEnabled: Boolean = true) {
        if (vibrationEnabled) {
            vibratePattern(longArrayOf(0, 100, 80, 100, 80, 300))
        }
        if (soundEnabled) {
            scope.launch {
                try {
                    val tones = listOf(
                        ToneGenerator.TONE_DTMF_1,
                        ToneGenerator.TONE_DTMF_4,
                        ToneGenerator.TONE_DTMF_7,
                        ToneGenerator.TONE_DTMF_0,
                        ToneGenerator.TONE_PROP_BEEP2
                    )
                    for (t in tones) {
                        toneGenerator?.startTone(t, 140)
                        delay(140)
                    }
                } catch (_: Exception) {}
            }
        }
    }

    private fun vibrate(durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    private fun vibratePattern(timings: LongArray) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(timings, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(timings, -1)
            }
        } catch (_: Exception) {}
    }

    fun release() {
        toneGenerator?.release()
        toneGenerator = null
    }
}
