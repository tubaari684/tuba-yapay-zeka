package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GameStats
import com.example.data.GeometryQuestionBank
import com.example.data.ScoreRepository
import com.example.model.ActiveModal
import com.example.model.AudienceVoteResult
import com.example.model.LifelinesState
import com.example.model.PhoneFriendCharacter
import com.example.model.PhoneResponse
import com.example.model.PrizeStep
import com.example.model.Question
import com.example.ui.components.OptionStatus
import com.example.util.SoundHapticManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

data class QuizUiState(
    val currentLevel: Int = 1,
    val currentQuestion: Question? = null,
    val selectedOptionIndex: Int? = null,
    val answerLocked: Boolean = false,
    val answerRevealed: Boolean = false,
    val eliminatedOptionIndices: Set<Int> = emptySet(),
    val lifelines: LifelinesState = LifelinesState(),
    val activeModal: ActiveModal = ActiveModal.NONE,
    val phoneResponse: PhoneResponse? = null,
    val audienceVoteResult: AudienceVoteResult? = null,
    val isGameOver: Boolean = false,
    val isVictory: Boolean = false,
    val walkedAway: Boolean = false,
    val finalPrizeAmount: Long = 0L,
    val guaranteedAmount: Long = 0L,
    val stats: GameStats = GameStats(),
    val usedQuestionIds: Set<Int> = emptySet()
)

class QuizViewModel(application: Application) : AndroidViewModel(application) {

    private val scoreRepo = ScoreRepository(application.applicationContext)
    val soundHaptic = SoundHapticManager(application.applicationContext)

    private val _uiState = MutableStateFlow(QuizUiState())
    val uiState: StateFlow<QuizUiState> = _uiState.asStateFlow()

    private var answerEvalJob: Job? = null

    init {
        loadStats()
        startNewGame()
    }

    fun loadStats() {
        val stats = scoreRepo.getStats()
        _uiState.update { it.copy(stats = stats) }
    }

    fun startNewGame() {
        answerEvalJob?.cancel()
        val firstQuestion = GeometryQuestionBank.getRandomQuestionForLevel(1)
        _uiState.update {
            QuizUiState(
                currentLevel = 1,
                currentQuestion = firstQuestion,
                selectedOptionIndex = null,
                answerLocked = false,
                answerRevealed = false,
                eliminatedOptionIndices = emptySet(),
                lifelines = LifelinesState(),
                activeModal = ActiveModal.NONE,
                phoneResponse = null,
                audienceVoteResult = null,
                isGameOver = false,
                isVictory = false,
                walkedAway = false,
                finalPrizeAmount = 0L,
                guaranteedAmount = 0L,
                stats = scoreRepo.getStats(),
                usedQuestionIds = setOf(firstQuestion.id)
            )
        }
    }

    fun selectOption(index: Int) {
        val state = _uiState.value
        if (state.answerLocked || state.isGameOver || state.eliminatedOptionIndices.contains(index)) return

        soundHaptic.playSelect(state.stats.soundEnabled, state.stats.vibrationEnabled)
        _uiState.update { it.copy(selectedOptionIndex = index) }
    }

    fun confirmAnswer() {
        val state = _uiState.value
        val selected = state.selectedOptionIndex ?: return
        val currentQ = state.currentQuestion ?: return
        if (state.answerLocked || state.isGameOver) return

        soundHaptic.playLockIn(state.stats.soundEnabled, state.stats.vibrationEnabled)
        _uiState.update { it.copy(answerLocked = true) }

        answerEvalJob = viewModelScope.launch {
            // Suspense pause (1.8 seconds)
            delay(1800)

            val isCorrect = (selected == currentQ.correctIndex)
            _uiState.update { it.copy(answerRevealed = true) }

            if (isCorrect) {
                soundHaptic.playCorrect(state.stats.soundEnabled, state.stats.vibrationEnabled)
                val currentStep = GeometryQuestionBank.prizeLadder.firstOrNull { it.level == state.currentLevel }
                val earnedSoFar = currentStep?.prizeAmount ?: 0L

                // Update guaranteed amount if passed a checkpoint
                var newGuaranteed = state.guaranteedAmount
                if (state.currentLevel >= 7) {
                    newGuaranteed = 15000L
                } else if (state.currentLevel >= 2) {
                    newGuaranteed = 1000L
                }

                delay(1800)

                if (state.currentLevel == 12) {
                    // GRAND PRIZE WINNER (500 Milyar!)
                    soundHaptic.playVictory(state.stats.soundEnabled, state.stats.vibrationEnabled)
                    scoreRepo.recordGameFinished(500000L, 12, wonGrandPrize = true)
                    _uiState.update {
                        it.copy(
                            isGameOver = true,
                            isVictory = true,
                            finalPrizeAmount = 500000L,
                            guaranteedAmount = 500000L,
                            stats = scoreRepo.getStats()
                        )
                    }
                } else {
                    // Proceed to next level
                    val nextLevel = state.currentLevel + 1
                    val nextQ = GeometryQuestionBank.getRandomQuestionForLevel(nextLevel, state.usedQuestionIds)
                    _uiState.update {
                        it.copy(
                            currentLevel = nextLevel,
                            currentQuestion = nextQ,
                            selectedOptionIndex = null,
                            answerLocked = false,
                            answerRevealed = false,
                            eliminatedOptionIndices = emptySet(),
                            guaranteedAmount = newGuaranteed,
                            usedQuestionIds = it.usedQuestionIds + nextQ.id
                        )
                    }
                }
            } else {
                // WRONG ANSWER: Player falls back to guaranteed checkpoint amount
                soundHaptic.playWrong(state.stats.soundEnabled, state.stats.vibrationEnabled)
                val finalWon = state.guaranteedAmount
                val answeredCount = (state.currentLevel - 1).coerceAtLeast(0)
                scoreRepo.recordGameFinished(finalWon, answeredCount, wonGrandPrize = false)

                delay(1800)
                _uiState.update {
                    it.copy(
                        isGameOver = true,
                        isVictory = false,
                        finalPrizeAmount = finalWon,
                        stats = scoreRepo.getStats()
                    )
                }
            }
        }
    }

    // LIFELINES
    fun useFiftyFifty() {
        val state = _uiState.value
        val q = state.currentQuestion ?: return
        if (state.lifelines.fiftyFiftyUsed || state.answerLocked || state.isGameOver) return

        soundHaptic.playLifeline(state.stats.soundEnabled, state.stats.vibrationEnabled)
        val wrongIndices = (0..3).filter { it != q.correctIndex }.shuffled()
        val toEliminate = wrongIndices.take(2).toSet()

        _uiState.update {
            it.copy(
                lifelines = it.lifelines.copy(fiftyFiftyUsed = true),
                eliminatedOptionIndices = toEliminate,
                selectedOptionIndex = if (toEliminate.contains(it.selectedOptionIndex)) null else it.selectedOptionIndex
            )
        }
    }

    fun openPhoneFriendModal() {
        val state = _uiState.value
        if (state.lifelines.phoneFriendUsed || state.answerLocked || state.isGameOver) return
        _uiState.update { it.copy(activeModal = ActiveModal.PHONE_FRIEND_SELECT, phoneResponse = null) }
    }

    fun executePhoneCall(character: PhoneFriendCharacter) {
        val state = _uiState.value
        val q = state.currentQuestion ?: return

        soundHaptic.playLifeline(state.stats.soundEnabled, state.stats.vibrationEnabled)
        val isCorrectSuggestion = (Random.nextFloat() <= character.baseAccuracy)

        val suggestedOption = if (isCorrectSuggestion) {
            q.correctIndex
        } else {
            (0..3).filter { it != q.correctIndex && !state.eliminatedOptionIndices.contains(it) }
                .randomOrNull() ?: q.correctIndex
        }

        val letters = listOf("A", "B", "C", "D")
        val letter = letters.getOrElse(suggestedOption) { "A" }

        val confidence = when (character) {
            PhoneFriendCharacter.MATH_TEACHER -> if (isCorrectSuggestion) Random.nextInt(88, 98) else Random.nextInt(60, 75)
            PhoneFriendCharacter.HONOR_STUDENT -> if (isCorrectSuggestion) Random.nextInt(82, 92) else Random.nextInt(55, 70)
            PhoneFriendCharacter.ENGINEER_UNCLE -> if (isCorrectSuggestion) Random.nextInt(75, 88) else Random.nextInt(50, 68)
        }

        val message = when (character) {
            PhoneFriendCharacter.MATH_TEACHER ->
                "Merhaba! 5. sınıf geometri müfredatından çok güzel bir soru. Geometrik tanım ve kurallar gereği cevap net şekilde $letter şıkkı görünüyor."
            PhoneFriendCharacter.HONOR_STUDENT ->
                "Selam! Bu konuyu defterime yazmıştım, öğretmenimiz üzerinde çok durdu. Kesinlikle $letter şıkkı doğru olmalı!"
            PhoneFriendCharacter.ENGINEER_UNCLE ->
                "Alo evlat! Biz projelerde ve çizimlerde bu açı ve doğru kurallarını sürekli kullanırız. Bence gönül rahatlığıyla $letter şıkkını seçebilirsin."
        }

        val response = PhoneResponse(
            character = character,
            suggestedOptionIndex = suggestedOption,
            confidencePercent = confidence,
            message = message
        )

        _uiState.update {
            it.copy(
                lifelines = it.lifelines.copy(phoneFriendUsed = true),
                phoneResponse = response,
                activeModal = ActiveModal.PHONE_FRIEND_RESULT
            )
        }
    }

    fun useAskAudience() {
        val state = _uiState.value
        val q = state.currentQuestion ?: return
        if (state.lifelines.askAudienceUsed || state.answerLocked || state.isGameOver) return

        soundHaptic.playLifeline(state.stats.soundEnabled, state.stats.vibrationEnabled)

        // Calculate audience voting percentages based on difficulty
        val correctIndex = q.correctIndex
        val correctPct = when (state.currentLevel) {
            in 1..4 -> Random.nextInt(70, 85)
            in 5..8 -> Random.nextInt(55, 72)
            else -> Random.nextInt(45, 60)
        }
        var remaining = 100 - correctPct
        val otherIndices = (0..3).filter { it != correctIndex }

        val votes = MutableList(4) { 0 }
        votes[correctIndex] = correctPct

        // If some options are eliminated by 50:50, don't give them many audience votes
        val validOthers = otherIndices.filter { !state.eliminatedOptionIndices.contains(it) }
        if (validOthers.isNotEmpty()) {
            for (i in 0 until validOthers.size - 1) {
                val share = Random.nextInt(0, remaining / (validOthers.size - i) + 5).coerceAtMost(remaining)
                votes[validOthers[i]] = share
                remaining -= share
            }
            votes[validOthers.last()] = remaining
        } else {
            votes[otherIndices.first()] = remaining
        }

        val result = AudienceVoteResult(percentages = votes)

        _uiState.update {
            it.copy(
                lifelines = it.lifelines.copy(askAudienceUsed = true),
                audienceVoteResult = result,
                activeModal = ActiveModal.AUDIENCE_POLL
            )
        }
    }

    fun useSwapQuestion() {
        val state = _uiState.value
        if (state.lifelines.swapQuestionUsed || state.answerLocked || state.isGameOver) return

        soundHaptic.playLifeline(state.stats.soundEnabled, state.stats.vibrationEnabled)
        val newQ = GeometryQuestionBank.getRandomQuestionForLevel(state.currentLevel, state.usedQuestionIds)

        _uiState.update {
            it.copy(
                lifelines = it.lifelines.copy(swapQuestionUsed = true),
                currentQuestion = newQ,
                selectedOptionIndex = null,
                eliminatedOptionIndices = emptySet(), // Reset elimination for new question
                usedQuestionIds = it.usedQuestionIds + newQ.id
            )
        }
    }

    fun openLadderModal() {
        _uiState.update { it.copy(activeModal = ActiveModal.MONEY_LADDER) }
    }

    fun openWalkAwayModal() {
        val state = _uiState.value
        if (state.answerLocked || state.isGameOver) return
        _uiState.update { it.copy(activeModal = ActiveModal.CONFIRM_WALKAWAY) }
    }

    fun confirmWalkAway() {
        val state = _uiState.value
        // Player walks away with the prize of the PREVIOUS question
        val previousLevel = state.currentLevel - 1
        val earnedPrize = if (previousLevel >= 1) {
            GeometryQuestionBank.prizeLadder.firstOrNull { it.level == previousLevel }?.prizeAmount ?: 0L
        } else {
            0L
        }

        soundHaptic.playLifeline(state.stats.soundEnabled, state.stats.vibrationEnabled)
        scoreRepo.recordGameFinished(earnedPrize, previousLevel.coerceAtLeast(0), wonGrandPrize = false)

        _uiState.update {
            it.copy(
                isGameOver = true,
                walkedAway = true,
                isVictory = false,
                finalPrizeAmount = earnedPrize,
                activeModal = ActiveModal.NONE,
                stats = scoreRepo.getStats()
            )
        }
    }

    fun dismissModal() {
        _uiState.update { it.copy(activeModal = ActiveModal.NONE) }
    }

    fun toggleSound(enabled: Boolean) {
        scoreRepo.setSoundEnabled(enabled)
        _uiState.update { it.copy(stats = it.stats.copy(soundEnabled = enabled)) }
    }

    fun toggleVibration(enabled: Boolean) {
        scoreRepo.setVibrationEnabled(enabled)
        _uiState.update { it.copy(stats = it.stats.copy(vibrationEnabled = enabled)) }
    }

    fun getOptionStatus(index: Int): OptionStatus {
        val state = _uiState.value
        val q = state.currentQuestion ?: return OptionStatus.DEFAULT

        if (state.eliminatedOptionIndices.contains(index)) {
            return OptionStatus.ELIMINATED
        }
        if (state.answerRevealed) {
            return when {
                index == q.correctIndex -> OptionStatus.CORRECT
                index == state.selectedOptionIndex -> OptionStatus.WRONG
                else -> OptionStatus.DEFAULT
            }
        }
        if (index == state.selectedOptionIndex) {
            return OptionStatus.SELECTED
        }
        return OptionStatus.DEFAULT
    }

    override fun onCleared() {
        super.onCleared()
        soundHaptic.release()
    }
}
