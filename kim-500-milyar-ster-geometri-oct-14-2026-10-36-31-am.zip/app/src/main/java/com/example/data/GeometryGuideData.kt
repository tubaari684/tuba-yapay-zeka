package com.example.data

data class GuideItem(
    val title: String,
    val subtitle: String,
    val symbol: String,
    val definition: String,
    val example: String,
    val keyRule: String
)

data class GuideCategory(
    val categoryName: String,
    val iconName: String,
    val items: List<GuideItem>
)

object GeometryGuideData {
    val categories: List<GuideCategory> = listOf(
        GuideCategory(
            categoryName = "Temel Geometrik Kavramlar",
            iconName = "line",
            items = listOf(
                GuideItem(
                    title = "Nokta",
                    subtitle = "Geometrinin en küçük yapı taşı",
                    symbol = "• A",
                    definition = "Boyutu, uzunluğu, genişliği ve yüksekliği olmayan, kalemin kağıtta bıraktığı izdir.",
                    example = "Haritadaki şehirler, gökyüzündeki yıldızlar, iğne ucu izi.",
                    keyRule = "Daima büyük harfle gösterilir (A noktası, B noktası gibi)."
                ),
                GuideItem(
                    title = "Doğru",
                    subtitle = "İki ucu da sonsuza uzayan çizgi",
                    symbol = "←—— A —— B ——→ (AB veya d doğrusu)",
                    definition = "Aynı doğrultudaki noktalar kümesidir. Her iki ucundan da sınırsızca sonsuza uzar.",
                    example = "Ufuk çizgisi, sonsuza giden düz tren rayı.",
                    keyRule = "Boyu ölçülemez, iki ucunda ok işaretleri bulunur. İki noktadan sadece bir doğru geçer."
                ),
                GuideItem(
                    title = "Doğru Parçası",
                    subtitle = "İki ucu sınırlandırılmış düz çizgi",
                    symbol = "[AB] veya [BA] (Uzunluğu: |AB|)",
                    definition = "Bir doğru üzerinde seçilen iki nokta ve bu noktalar arasında kalan kısımdır.",
                    example = "Cetvel, kibrit çöpü, gergin bir ip parçası, kurşun kalem.",
                    keyRule = "Her iki ucu da kapalıdır, boyu cetvelle ölçülebilir (|AB| = 6 cm)."
                ),
                GuideItem(
                    title = "Işın",
                    subtitle = "Bir ucu kapalı, diğer ucu sonsuza uzanır",
                    symbol = "[AB) (A kapalı, B sonsuz)",
                    definition = "Başlangıç noktası sabit olup diğer yönde sınırsız uzayan düz çizgidir.",
                    example = "Güneş ışınları, el fenerinin yaydığı ışık, çivi, örgü şişi.",
                    keyRule = "Başlangıç noktası köşeli parantez ile yazılır: [AB)."
                )
            )
        ),
        GuideCategory(
            categoryName = "Doğruların Konumları",
            iconName = "parallel",
            items = listOf(
                GuideItem(
                    title = "Paralel Doğrular",
                    subtitle = "Asla kesişmeyen doğrular",
                    symbol = "d // k",
                    definition = "Aynı düzlemde bulunan ve uzatıldıklarında hiçbir zaman kesişmeyen, aralarındaki uzaklık hep eşit olan doğrulardır.",
                    example = "Karşılıklı tren rayları, cetvelin iki uzun kenarı, merdiven basamakları.",
                    keyRule = "Paralel doğruların ortak kesişim noktası yoktur."
                ),
                GuideItem(
                    title = "Dik Kesişen Doğrular",
                    subtitle = "90 derecelik açıyla kesişenler",
                    symbol = "AB ⊥ CD",
                    definition = "Kesiştiklerinde aralarında tam 90° (dik açı) oluşturan doğrulardır.",
                    example = "Pencere çerçevesinin yatay ve dikey kenarları, artı (+) işareti.",
                    keyRule = "Diklik sembolü '⊥' işaretidir. Kesişim noktasında 4 adet 90° açı oluşur."
                ),
                GuideItem(
                    title = "Kesişen Doğrular",
                    subtitle = "Tek bir noktası ortak olan doğrular",
                    symbol = "d ∩ k = {O}",
                    definition = "Aynı düzlemde bulunan ve yalnızca bir ortak noktası olan doğrulardır.",
                    example = "Açılmış makas, çarpı (X) işareti, yol kavşağı.",
                    keyRule = "Kesişen iki doğrunun karşılıklı açıları (ters açılar) birbirine eşittir."
                )
            )
        ),
        GuideCategory(
            categoryName = "Açılar ve Çeşitleri",
            iconName = "angle",
            items = listOf(
                GuideItem(
                    title = "Dar Açı",
                    subtitle = "0° ile 90° arasındaki açılar",
                    symbol = "0° < s(Â) < 90°",
                    definition = "Ölçüsü 0 dereceden büyük ve 90 dereceden küçük olan açılardır.",
                    example = "Az açılmış makas, saat 2:00'deki açı (60°), 45° gönye açısı.",
                    keyRule = "En büyük tam sayı dar açı 89°'dir."
                ),
                GuideItem(
                    title = "Dik Açı",
                    subtitle = "Ölçüsü tam 90° olan açı",
                    symbol = "s(Â) = 90° (Sembolü: ∟)",
                    definition = "Ölçüsü tam olarak 90 derece olan açıdır. Köşeli ve noktalı sembolle gösterilir.",
                    example = "Saat 3:00 ve 9:00, oda duvarı ile zemin köşesi, defter kenarı.",
                    keyRule = "Doğruların dik kesişmesiyle oluşur. Açıölçerde tam 90 derecedir."
                ),
                GuideItem(
                    title = "Geniş Açı",
                    subtitle = "90° ile 180° arasındaki açılar",
                    symbol = "90° < s(Â) < 180°",
                    definition = "Ölçüsü dik açıdan (90°) büyük, doğru açıdan (180°) küçük olan açılardır.",
                    example = "Saat 5:00'te akrep ile yelkovan (150°), iyice açılmış yelpaze.",
                    keyRule = "En küçük tam sayı geniş açı 91°, en büyük ise 179°'dir."
                ),
                GuideItem(
                    title = "Doğru Açı & Tam Açı",
                    subtitle = "180° ve 360° açılar",
                    symbol = "Doğru = 180°, Tam = 360°",
                    definition = "Kolları zıt yönlü doğru oluşturan açı doğru açı (180°), tam bir tur dönen açı tam açıdır (360°).",
                    example = "Saat 6:00'da kollar (180°), dönme dolabın tam turu (360°).",
                    keyRule = "1 Doğru Açı = 2 Dik Açı. 1 Tam Açı = 4 Dik Açı."
                )
            )
        ),
        GuideCategory(
            categoryName = "Üçgenler ve Dörtgenler",
            iconName = "triangle",
            items = listOf(
                GuideItem(
                    title = "Üçgenin İç Açıları",
                    subtitle = "Toplamı daima 180 derecedir",
                    symbol = "s(A) + s(B) + s(C) = 180°",
                    definition = "Bütün üçgenlerin üç iç açısının ölçüleri toplamı istisnasız 180° eder.",
                    example = "Bir açısı 70°, diğeri 50° ise: 180 - (70+50) = 60° kalır.",
                    keyRule = "Bir üçgende birden fazla dik veya geniş açı olamaz!"
                ),
                GuideItem(
                    title = "Eşkenar ve İkizkenar Üçgen",
                    subtitle = "Kenarlarına göre üçgenler",
                    symbol = "Eşkenar: Her açı 60°",
                    definition = "Eşkenar üçgenin 3 kenarı ve 3 açısı da 60°'dir. İkizkenar üçgende 2 kenar ve taban açıları eşittir.",
                    example = "Trafik uyarı levhaları çoğunlukla eşkenar üçgendir.",
                    keyRule = "Eşkenar üçgen aynı zamanda tüm açıları dar olan bir dar açılı üçgendir."
                ),
                GuideItem(
                    title = "Dörtgenlerin İç Açıları",
                    subtitle = "Kare, dikdörtgen vb. toplamı 360°",
                    symbol = "İç açılar toplamı = 360°",
                    definition = "Kare, dikdörtgen, paralelkenar ve yamuk gibi tüm dörtgenlerin iç açıları toplamı 360° eder.",
                    example = "Karenin 4 dik açısı vardır: 4 × 90° = 360°.",
                    keyRule = "Dörtgen bir köşegeni ile 2 üçgene ayrıldığı için: 2 × 180° = 360°."
                )
            )
        )
    )
}
