package com.example.data

import com.example.model.DiagramData
import com.example.model.DiagramType
import com.example.model.GeometryTopic
import com.example.model.PrizeStep
import com.example.model.Question

object GeometryQuestionBank {

    val prizeLadder: List<PrizeStep> = listOf(
        PrizeStep(1, 500L, "500 TL", isCheckpoint = false),
        PrizeStep(2, 1000L, "1.000 TL", isCheckpoint = true),   // 1. Baraj
        PrizeStep(3, 2000L, "2.000 TL", isCheckpoint = false),
        PrizeStep(4, 3000L, "3.000 TL", isCheckpoint = false),
        PrizeStep(5, 5000L, "5.000 TL", isCheckpoint = false),
        PrizeStep(6, 7500L, "7.500 TL", isCheckpoint = false),
        PrizeStep(7, 15000L, "15.000 TL", isCheckpoint = true),  // 2. Baraj
        PrizeStep(8, 30000L, "30.000 TL", isCheckpoint = false),
        PrizeStep(9, 60000L, "60.000 TL", isCheckpoint = false),
        PrizeStep(10, 125000L, "125.000 TL", isCheckpoint = false),
        PrizeStep(11, 250000L, "250.000 TL", isCheckpoint = false),
        PrizeStep(12, 500000L, "500.000 TL", isCheckpoint = true) // Büyük Ödül (500 Milyar)
    )

    private val allQuestions: List<Question> = listOf(
        // LEVEL 1 (500 TL)
        Question(
            id = 101,
            level = 1,
            questionText = "Sivri uçlu bir kalemin beyaz bir kağıda dokundurulduğunda bıraktığı en küçük ize matematikte ne ad verilir?",
            options = listOf("Nokta", "Doğru", "Açı", "Çember"),
            correctIndex = 0,
            topic = GeometryTopic.NOKTA_DOGRU_ISIN,
            explanation = "Nokta, boyutu ve kalınlığı olmayan, kalemin kağıtta bıraktığı iz olarak modellenen temel geometrik kavramdır. Büyük harfle gösterilir (A noktası gibi)."
        ),
        Question(
            id = 102,
            level = 1,
            questionText = "Geometride noktalar genellikle nasıl isimlendirilir ve gösterilir?",
            options = listOf("Küçük harflerle", "Büyük harflerle", "Rakamlarla", "Yalnızca şekillerle"),
            correctIndex = 1,
            topic = GeometryTopic.NOKTA_DOGRU_ISIN,
            explanation = "Geometride noktalar alfabenin 'A, B, C, K' gibi büyük harfleri ile isimlendirilir."
        ),
        Question(
            id = 103,
            level = 1,
            questionText = "Her iki yönden de istenildiği kadar uzatılabilen, kalınlığı olmayan çizgi modeli aşağıdakilerden hangisidir?",
            options = listOf("Işın", "Doğru parçası", "Doğru", "Açı"),
            correctIndex = 2,
            topic = GeometryTopic.NOKTA_DOGRU_ISIN,
            explanation = "Doğru, iki ucundan da sınırsızca sonsuza kadar uzayan düz bir çizgidir. Bu yüzden her iki ucuna da ok işareti konulur.",
            diagramData = DiagramData(type = DiagramType.LINE, labelA = "A", labelB = "B")
        ),

        // LEVEL 2 (1.000 TL - 1. BARAJ)
        Question(
            id = 201,
            level = 2,
            questionText = "Görseldeki gibi başlangıç noktası sabit olan ve diğer ucu sonsuza doğru uzanan geometrik şekle ne denir?",
            options = listOf("Doğru", "Doğru Parçası", "Işın", "Düzlem"),
            correctIndex = 2,
            topic = GeometryTopic.NOKTA_DOGRU_ISIN,
            explanation = "Başlangıç noktası kapalı (sabit) olup tek bir yönde sonsuza uzayan geometrik kavrama 'Işın' denir. El fenerinden çıkan ışık veya çivi ışına örnektir.",
            diagramData = DiagramData(type = DiagramType.RAY, labelA = "A", labelB = "B")
        ),
        Question(
            id = 202,
            level = 2,
            questionText = "Günlük hayattan verilen 'Güneş ışınları' ve 'El fenerinin yaydığı ışık' en çok hangi geometrik kavramı modeller?",
            options = listOf("Doğru parçası", "Işın", "Kesişen doğrular", "Tam açı"),
            correctIndex = 1,
            topic = GeometryTopic.NOKTA_DOGRU_ISIN,
            explanation = "Güneş ve el feneri ışığın çıktığı sabit başlangıç noktasıdır ve ışık sonsuza yayılır; bu durum ışın modeline en uygun örnektir."
        ),
        Question(
            id = 203,
            level = 2,
            questionText = "İki ucu da sınırlandırılmış, boyu cetvelle ölçülebilen düz çizgi parçasına ne ad verilir?",
            options = listOf("Doğru", "Işın", "Doğru Parçası", "Açıortay"),
            correctIndex = 2,
            topic = GeometryTopic.NOKTA_DOGRU_ISIN,
            explanation = "İki ucu da kapalı ve başlangıç ile bitiş noktaları belli olan düz çizgiye 'Doğru Parçası' denir. Uzunluğu cetvelle ölçülebilir.",
            diagramData = DiagramData(type = DiagramType.LINE_SEGMENT, labelA = "K", labelB = "L")
        ),

        // LEVEL 3 (2.000 TL)
        Question(
            id = 301,
            level = 3,
            questionText = "A noktası kapalı, B noktası sonsuza uzanan bir ışının sembolle gösterimi aşağıdakilerden hangisidir?",
            options = listOf("[AB]", "[AB)", "(AB)", "AB"),
            correctIndex = 1,
            topic = GeometryTopic.NOKTA_DOGRU_ISIN,
            explanation = "Kapalı olan uç köşeli parantez '[' ile, açık ve sonsuza uzanan uç parantezsiz veya ')' ile gösterilir: [AB) şeklinde yazılır."
        ),
        Question(
            id = 302,
            level = 3,
            questionText = "Uçları A ve B noktaları olan bir 'Doğru Parçası'nın uzunluğu sembolle nasıl gösterilir?",
            options = listOf("[AB]", "|AB|", "AB)", "s(AB)"),
            correctIndex = 1,
            topic = GeometryTopic.NOKTA_DOGRU_ISIN,
            explanation = "Doğru parçasının kendisi [AB] ile, uzunluğu (boyu) ise iki dik çizgi arasında |AB| sembolüyle gösterilir (Örneğin: |AB| = 8 cm)."
        ),
        Question(
            id = 303,
            level = 3,
            questionText = "Bir doğru üzerinde yer alan 2 farklı nokta arasında kalan bölgeye ne ad verilir?",
            options = listOf("Işın", "Doğru parçası", "Geniş açı", "Nokta kümesi"),
            correctIndex = 1,
            topic = GeometryTopic.NOKTA_DOGRU_ISIN,
            explanation = "Bir doğru üzerindeki iki nokta ve bu noktalar arasında kalan kısım bir 'Doğru Parçası' oluşturur."
        ),

        // LEVEL 4 (3.000 TL)
        Question(
            id = 401,
            level = 4,
            questionText = "Aynı düzlemde bulunan ve uzatıldıklarında hiçbir zaman kesişmeyen doğrulara ne ad verilir?",
            options = listOf("Kesişen doğrular", "Paralel doğrular", "Çakışan doğrular", "Dik doğrular"),
            correctIndex = 1,
            topic = GeometryTopic.DOGRU_KONUMLARI,
            explanation = "Aynı düzlemde birbirini hiçbir zaman kesmeyen ve aralarındaki mesafe daima sabit kalan doğrulara paralel doğrular denir. 'd // k' şeklinde gösterilir.",
            diagramData = DiagramData(type = DiagramType.PARALLEL_LINES, labelA = "d", labelB = "k")
        ),
        Question(
            id = 402,
            level = 4,
            questionText = "Tren rayları veya standart bir cetvelin karşılıklı iki kenarı hangi doğru konumuna en iyi örnektir?",
            options = listOf("Dik kesişen doğrular", "Paralel doğrular", "Çakışan doğrular", "Tek noktada kesişen doğrular"),
            correctIndex = 1,
            topic = GeometryTopic.DOGRU_KONUMLARI,
            explanation = "Tren rayları ve cetvelin kenarları boyunca aralarındaki uzaklık hep eşittir ve raylar asla kesişmez; dolayısıyla paralel doğrulara örnektir."
        ),
        Question(
            id = 403,
            level = 4,
            questionText = "'m' ve 'n' doğrularının paralel olduğunu gösteren matematiksel sembol hangisidir?",
            options = listOf("m ⊥ n", "m // n", "m = n", "m ∩ n = {A}"),
            correctIndex = 1,
            topic = GeometryTopic.DOGRU_KONUMLARI,
            explanation = "Paralellik iki eğik çizgi sembolü ile ifade edilir: m // n."
        ),

        // LEVEL 5 (5.000 TL)
        Question(
            id = 501,
            level = 5,
            questionText = "Birbirini 90 derecelik açı ile kesen iki doğruya ne ad verilir?",
            options = listOf("Paralel doğrular", "Dik kesişen doğrular", "Çakışan doğrular", "Aykırı doğrular"),
            correctIndex = 1,
            topic = GeometryTopic.DOGRU_KONUMLARI,
            explanation = "Aralarındaki açı 90° (dik açı) olan doğrulara 'dik kesişen doğrular' denir. 'AB ⊥ CD' sembolüyle gösterilir.",
            diagramData = DiagramData(type = DiagramType.PERPENDICULAR_LINES, labelA = "AB", labelB = "CD")
        ),
        Question(
            id = 502,
            level = 5,
            questionText = "'k' doğrusu ile 'p' doğrusunun birbirine dik olduğunu belirten sembol aşağıdakilerden hangisidir?",
            options = listOf("k // p", "k ⊥ p", "k = p", "k ≅ p"),
            correctIndex = 1,
            topic = GeometryTopic.DOGRU_KONUMLARI,
            explanation = "Diklik sembolü ters 'T' şeklinde olan '⊥' sembolüdür: k ⊥ p okunurken 'k doğrusu diktir p doğrusuna' denir."
        ),
        Question(
            id = 503,
            level = 5,
            questionText = "Aynı düzlemde bulunan ve yalnızca bir ortak noktası olan iki doğruya ne ad verilir?",
            options = listOf("Paralel doğrular", "Çakışan doğrular", "Kesişen doğrular", "Doğru parçası"),
            correctIndex = 2,
            topic = GeometryTopic.DOGRU_KONUMLARI,
            explanation = "Düzlemde tek bir noktada buluşan doğrular 'kesişen doğrular' olarak adlandırılır. Örneğin makas kollarının birleştiği vida kesişim noktasıdır.",
            diagramData = DiagramData(type = DiagramType.INTERSECTING_LINES, labelA = "d₁", labelB = "d₂")
        ),

        // LEVEL 6 (7.500 TL)
        Question(
            id = 601,
            level = 6,
            questionText = "Başlangıç noktaları ortak olan iki ışının birleşmesiyle oluşan geometrik şekle ne denir?",
            options = listOf("Doğru", "Açı", "Çokgen", "Düzlem"),
            correctIndex = 1,
            topic = GeometryTopic.ACILAR,
            explanation = "Başlangıç noktaları aynı olan iki ışının oluşturduğu açıklığa 'Açı' denir. Ortak başlangıç noktasına açının köşesi, ışınlara ise açının kolları (kenarları) denir."
        ),
        Question(
            id = 602,
            level = 6,
            questionText = "Ölçüsü tam olarak 90 derece olan açıya ne ad verilir?",
            options = listOf("Dar açı", "Dik açı", "Geniş açı", "Doğru açı"),
            correctIndex = 1,
            topic = GeometryTopic.ACILAR,
            explanation = "Ölçüsü 90° olan açıya dik açı denir. Kitap kapağının köşesi veya pencere kenarları dik açıya örnektir.",
            diagramData = DiagramData(type = DiagramType.RIGHT_ANGLE, angleDegree = 90f, labelA = "A", labelB = "B", labelC = "C")
        ),
        Question(
            id = 603,
            level = 6,
            questionText = "Bir açının ölçüsünü ölçmek ve açı çizmek için kullanılan yarım daire şeklindeki matematik aletinin adı nedir?",
            options = listOf("Pergel", "İletki (Açıölçer)", "T cetveli", "Gönyeli terazi"),
            correctIndex = 1,
            topic = GeometryTopic.ACILAR,
            explanation = "Açıların derecesini belirlemek ve belirli derecede açı çizmek için 'İletki' (diğer adıyla 'Açıölçer') kullanılır."
        ),

        // LEVEL 7 (15.000 TL - 2. BARAJ)
        Question(
            id = 701,
            level = 7,
            questionText = "Ölçüsü 0 derece ile 90 derece arasında olan açılara ne ad verilir?",
            options = listOf("Dik açı", "Dar açı", "Geniş açı", "Tam açı"),
            correctIndex = 1,
            topic = GeometryTopic.ACILAR,
            explanation = "0°'den büyük ve 90°'den küçük olan tüm açılara 'Dar Açı' denir (Örn: 25°, 45°, 89°).",
            diagramData = DiagramData(type = DiagramType.ACUTE_ANGLE, angleDegree = 50f, labelA = "D", labelB = "E", labelC = "F")
        ),
        Question(
            id = 702,
            level = 7,
            questionText = "Aşağıdaki derece ölçülerinden hangisi bir 'Dar Açı' modelidir?",
            options = listOf("90°", "91°", "89°", "180°"),
            correctIndex = 2,
            topic = GeometryTopic.ACILAR,
            explanation = "89 derece 90'dan küçük olduğu için dar açıdır. 90° dik açı, 91° geniş açı, 180° ise doğru açıdır."
        ),
        Question(
            id = 703,
            level = 7,
            questionText = "Ölçüsü 90 dereceden büyük, 180 dereceden küçük olan açı çeşitine ne ad verilir?",
            options = listOf("Dar açı", "Tam açı", "Geniş açı", "Doğru açı"),
            correctIndex = 2,
            topic = GeometryTopic.ACILAR,
            explanation = "90° ile 180° arasında bulunan açılara 'Geniş Açı' denir (Örn: 95°, 120°, 179°).",
            diagramData = DiagramData(type = DiagramType.OBTUSE_ANGLE, angleDegree = 125f, labelA = "K", labelB = "L", labelC = "M")
        ),

        // LEVEL 8 (30.000 TL)
        Question(
            id = 801,
            level = 8,
            questionText = "Saat tam 03:00 iken akrep ile yelkovan arasında oluşan küçük açı kaç derecedir ve çeşidi nedir?",
            options = listOf("45° - Dar açı", "90° - Dik açı", "120° - Geniş açı", "180° - Doğru açı"),
            correctIndex = 1,
            topic = GeometryTopic.ACILAR,
            explanation = "Saat 3:00'te akrep 3'ü, yelkovan 12'yi gösterir. Aralarındaki açı tam 90 derecedir ve bir dik açıdır.",
            diagramData = DiagramData(type = DiagramType.CLOCK_TIME, clockHour = 3, clockMinute = 0)
        ),
        Question(
            id = 802,
            level = 8,
            questionText = "Saat tam 06:00'da akrep ile yelkovanın oluşturduğu düz açının ölçüsü kaç derecedir?",
            options = listOf("90°", "120°", "180°", "360°"),
            correctIndex = 2,
            topic = GeometryTopic.ACILAR,
            explanation = "Saat 6:00'da akrep 6'yı, yelkovan 12'yi göstererek zıt yönde düz bir çizgi oluşturur. Ölçüsü 180° olan bu açıya 'Doğru Açı' denir.",
            diagramData = DiagramData(type = DiagramType.CLOCK_TIME, clockHour = 6, clockMinute = 0)
        ),
        Question(
            id = 803,
            level = 8,
            questionText = "Bir doğru açının ölçüsü, dik açının ölçüsünün kaç katıdır?",
            options = listOf("1 katı", "2 katı", "3 katı", "4 katı"),
            correctIndex = 1,
            topic = GeometryTopic.ACILAR,
            explanation = "Doğru açı 180°, dik açı 90° olduğuna göre; 180 / 90 = 2 katıdır. İki dik açının birleşimi bir doğru açı eder."
        ),

        // LEVEL 9 (60.000 TL)
        Question(
            id = 901,
            level = 9,
            questionText = "Tüm üçgenlerin iç açıları ölçüleri toplamı daima kaç derecedir?",
            options = listOf("90°", "180°", "270°", "360°"),
            correctIndex = 1,
            topic = GeometryTopic.UCGENLER_DORTGENLER,
            explanation = "Geometrideki temel kural gereği, şekli ve boyutu ne olursa olsun bütün üçgenlerin iç açıları toplamı 180 derecedir."
        ),
        Question(
            id = 902,
            level = 9,
            questionText = "Bir ABC üçgeninde s(A) = 60° ve s(B) = 70° olduğuna göre, verilmeyen C açısı kaç derecedir?",
            options = listOf("40°", "50°", "60°", "70°"),
            correctIndex = 1,
            topic = GeometryTopic.UCGENLER_DORTGENLER,
            explanation = "Üçgenin iç açıları toplamı 180°'dir. 60° + 70° = 130°. Kalan C açısı: 180° - 130° = 50° bulunur.",
            diagramData = DiagramData(type = DiagramType.TRIANGLE_ANGLES, knownAngle1 = 60, knownAngle2 = 70)
        ),
        Question(
            id = 903,
            level = 9,
            questionText = "Bütün kenar uzunlukları birbirine eşit olan bir 'Eşkenar Üçgen'in bir iç açısının ölçüsü kaç derecedir?",
            options = listOf("45°", "60°", "90°", "120°"),
            correctIndex = 1,
            topic = GeometryTopic.UCGENLER_DORTGENLER,
            explanation = "Eşkenar üçgenin hem tüm kenarları hem de üç açısı birbirine eşittir. İç açılar toplamı 180° olduğuna göre: 180 / 3 = 60°'dir."
        ),

        // LEVEL 10 (125.000 TL)
        Question(
            id = 1001,
            level = 10,
            questionText = "Bir üçgende en fazla kaç tane 'Geniş Açı' bulunabilir?",
            options = listOf("1", "2", "3", "Hiç bulunamaz"),
            correctIndex = 0,
            topic = GeometryTopic.UCGENLER_DORTGENLER,
            explanation = "Geniş açı 90°'den büyüktür. İki tane geniş açı olsaydı toplamları 180°'yi geçerdi. Dolayısıyla bir üçgende en fazla 1 adet geniş açı bulunabilir."
        ),
        Question(
            id = 1002,
            level = 10,
            questionText = "İki kenar uzunluğu birbirine eşit olan üçgenlere kenarlarına göre ne ad verilir?",
            options = listOf("Eşkenar üçgen", "Çeşitkenar üçgen", "İkizkenar üçgen", "Dik açılı üçgen"),
            correctIndex = 2,
            topic = GeometryTopic.UCGENLER_DORTGENLER,
            explanation = "İki kenarı ve bu kenarların karşısındaki taban açıları birbirine eşit olan üçgenlere 'İkizkenar Üçgen' denir."
        ),
        Question(
            id = 1003,
            level = 10,
            questionText = "Açılarından biri 90° olan bir dik üçgende, diğer iki dar açının toplamı kaç derecedir?",
            options = listOf("45°", "60°", "90°", "180°"),
            correctIndex = 2,
            topic = GeometryTopic.UCGENLER_DORTGENLER,
            explanation = "Toplam 180° olduğuna göre ve bir açı 90° ise, geriye kalan iki açının toplamı daima 180° - 90° = 90° olmalıdır (birbirini 90°'ye tamamlar)."
        ),

        // LEVEL 11 (250.000 TL)
        Question(
            id = 1101,
            level = 11,
            questionText = "Kare, dikdörtgen ve paralelkenar gibi tüm dörtgenlerin iç açıları ölçüleri toplamı kaç derecedir?",
            options = listOf("180°", "270°", "360°", "540°"),
            correctIndex = 2,
            topic = GeometryTopic.UCGENLER_DORTGENLER,
            explanation = "Bir dörtgen bir köşegeni ile 2 tane üçgene ayrılır. Her üçgenin iç açıları toplamı 180° olduğundan, dörtgenlerin iç açıları toplamı 2 × 180° = 360°'dir."
        ),
        Question(
            id = 1102,
            level = 11,
            questionText = "Aşağıdaki geometrik şekillerden hangisinin karşılıklı kenarları paralel DEĞİLDİR?",
            options = listOf("Kare", "Dikdörtgen", "Eşkenar Dörtgen", "Çeşitkenar Üçgen"),
            correctIndex = 3,
            topic = GeometryTopic.UCGENLER_DORTGENLER,
            explanation = "Üçgenlerin kenarları kesişir ve üçgenlerde karşılıklı kenar çifti bulunmaz. Kare, dikdörtgen ve eşkenar dörtgenin karşılıklı kenarları ise paraleldir."
        ),
        Question(
            id = 1103,
            level = 11,
            questionText = "Bir ikizkenar üçgenin tepe açısı 80° olduğuna göre, taban açılarından birinin ölçüsü kaç derecedir?",
            options = listOf("50°", "60°", "80°", "100°"),
            correctIndex = 0,
            topic = GeometryTopic.UCGENLER_DORTGENLER,
            explanation = "İç açılar toplamı 180°'dir. 180° - 80° = 100° kalır. İkizkenar üçgende iki taban açısı birbirine eşit olduğundan: 100° / 2 = 50° bulunur."
        ),

        // LEVEL 12 (500.000 TL - BÜYÜK ÖDÜL: 500 MİLYAR!)
        Question(
            id = 1201,
            level = 12,
            questionText = "Bir noktadan sonsuz sayıda doğru geçerken, düzlemde verilen FARKLI İKİ NOKTADAN kaç farklı doğru geçer?",
            options = listOf("Yalnızca 1", "2", "3", "Sonsuz sayıda"),
            correctIndex = 0,
            topic = GeometryTopic.NOKTA_DOGRU_ISIN,
            explanation = "Geometrinin en temel aksiyomlarından biri şudur: Bir noktadan sonsuz sayıda doğru geçer, fakat farklı iki noktadan YALNIZCA BİR tek doğru geçer!"
        ),
        Question(
            id = 1202,
            level = 12,
            questionText = "Ölçüsü en büyük tam sayı olan dar açı ile ölçüsü en küçük tam sayı olan geniş açının toplamı kaç derecedir?",
            options = listOf("179°", "180°", "181°", "190°"),
            correctIndex = 1,
            topic = GeometryTopic.ACILAR,
            explanation = "En büyük dar açı tam sayı olarak 89°'dir. En küçük geniş açı tam sayı olarak 91°'dir. Bu ikisinin toplamı: 89° + 91° = 180° (yani bir doğru açı) eder!"
        ),
        Question(
            id = 1203,
            level = 12,
            questionText = "Düzlemde kesişen iki doğru ile ilgili olarak, komşu açılardan biri 65° ise, bu açının tam karşısındaki ters açının ölçüsü kaç derecedir?",
            options = listOf("25°", "65°", "115°", "180°"),
            correctIndex = 1,
            topic = GeometryTopic.ACILAR,
            explanation = "Kesişen iki doğrunun oluşturduğu zıt yönlü açılara ters açılar denir ve ters açıların ölçüleri birbirine daima eşittir. Dolayısıyla karşısındaki açı da 65°'dir."
        )
    )

    fun getRandomQuestionForLevel(level: Int, excludeIds: Set<Int> = emptySet()): Question {
        val pool = allQuestions.filter { it.level == level && !excludeIds.contains(it.id) }
        return if (pool.isNotEmpty()) {
            pool.random()
        } else {
            // Fallback if all questions seen
            allQuestions.filter { it.level == level }.random()
        }
    }
}
