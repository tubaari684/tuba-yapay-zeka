package com.example.data

import android.content.Context
import android.content.SharedPreferences

data class GameStats(
    val highestPrize: Long = 0L,
    val gamesPlayed: Int = 0,
    val millionaireWins: Int = 0,
    val totalQuestionsAnsweredCorrect: Int = 0,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true
)

class ScoreRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("geo_millionaire_prefs", Context.MODE_PRIVATE)

    fun getStats(): GameStats {
        return GameStats(
            highestPrize = prefs.getLong(KEY_HIGHEST_PRIZE, 0L),
            gamesPlayed = prefs.getInt(KEY_GAMES_PLAYED, 0),
            millionaireWins = prefs.getInt(KEY_MILLIONAIRE_WINS, 0),
            totalQuestionsAnsweredCorrect = prefs.getInt(KEY_CORRECT_COUNT, 0),
            soundEnabled = prefs.getBoolean(KEY_SOUND, true),
            vibrationEnabled = prefs.getBoolean(KEY_VIBRATION, true)
        )
    }

    fun recordGameFinished(finalPrize: Long, correctCount: Int, wonGrandPrize: Boolean) {
        val currentHighest = prefs.getLong(KEY_HIGHEST_PRIZE, 0L)
        val newHighest = maxOf(currentHighest, finalPrize)
        val games = prefs.getInt(KEY_GAMES_PLAYED, 0) + 1
        val wins = prefs.getInt(KEY_MILLIONAIRE_WINS, 0) + if (wonGrandPrize) 1 else 0
        val totalCorrect = prefs.getInt(KEY_CORRECT_COUNT, 0) + correctCount

        prefs.edit()
            .putLong(KEY_HIGHEST_PRIZE, newHighest)
            .putInt(KEY_GAMES_PLAYED, games)
            .putInt(KEY_MILLIONAIRE_WINS, wins)
            .putInt(KEY_CORRECT_COUNT, totalCorrect)
            .apply()
    }

    fun setSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SOUND, enabled).apply()
    }

    fun setVibrationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_VIBRATION, enabled).apply()
    }

    companion object {
        private const val KEY_HIGHEST_PRIZE = "highest_prize"
        private const val KEY_GAMES_PLAYED = "games_played"
        private const val KEY_MILLIONAIRE_WINS = "millionaire_wins"
        private const val KEY_CORRECT_COUNT = "correct_count"
        private const val KEY_SOUND = "sound_enabled"
        private const val KEY_VIBRATION = "vibration_enabled"
    }
}
