package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.GeometryQuestionBank
import com.example.model.PrizeStep
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CheckpointGold
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.MillionaireGold
import com.example.ui.theme.MillionaireGoldLight
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSilver
import com.example.ui.theme.TextWhite

@Composable
fun MoneyLadderDialog(
    currentLevel: Int,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(StudioNavySurface, StudioNavyDark)
                    )
                )
                .border(2.dp, MillionaireGold, RoundedCornerShape(20.dp))
                .padding(18.dp)
                .testTag("dialog_money_ladder")
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PARA AĞACI",
                        color = MillionaireGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("btn_close_ladder")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Kapat",
                            tint = TextSilver
                        )
                    }
                }

                Text(
                    text = "Baraj sorularını geçersen ödülün garanti altına alınır!",
                    color = TextSilver,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // List of 12 levels in descending order (12 down to 1)
                val reversedLadder = GeometryQuestionBank.prizeLadder.reversed()

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(reversedLadder) { step ->
                        MoneyLadderItem(
                            step = step,
                            isCurrent = step.level == currentLevel,
                            isPassed = step.level < currentLevel
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioAmber),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_ladder_ok")
                ) {
                    Text("Yarışmaya Dön", color = StudioNavyDark, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun MoneyLadderItem(
    step: PrizeStep,
    isCurrent: Boolean,
    isPassed: Boolean
) {
    val bgColor = when {
        isCurrent -> StudioAmber.copy(alpha = 0.25f)
        isPassed -> CorrectGreen.copy(alpha = 0.15f)
        step.isCheckpoint -> CheckpointGold.copy(alpha = 0.10f)
        else -> StudioNavyCard.copy(alpha = 0.5f)
    }

    val borderColor = when {
        isCurrent -> MillionaireGold
        isPassed -> CorrectGreen
        step.isCheckpoint -> CheckpointGold
        else -> Color.Transparent
    }

    val textColor = when {
        isCurrent -> MillionaireGoldLight
        isPassed -> CorrectGreen
        step.isCheckpoint -> CheckpointGold
        else -> TextSilver
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(if (isCurrent || step.isCheckpoint || isPassed) 1.5.dp else 0.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${step.level}.",
                    color = textColor,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(28.dp)
                )

                if (step.level == 12) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Büyük Ödül",
                        tint = MillionaireGold,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }

                Text(
                    text = if (step.level == 12) "500 MİLYAR (500.000 TL)" else step.displayAmount,
                    color = textColor,
                    fontSize = if (isCurrent) 15.sp else 13.sp,
                    fontWeight = if (isCurrent || step.isCheckpoint) FontWeight.ExtraBold else FontWeight.Medium
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isCurrent) {
                    Text(
                        text = "▶ ŞU AN",
                        color = MillionaireGoldLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                } else if (isPassed) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Geçildi",
                        tint = CorrectGreen,
                        modifier = Modifier.padding(start = 4.dp)
                    )
                } else if (step.isCheckpoint) {
                    Text(
                        text = if (step.level == 12) "ŞAMPİYONLUK" else "BARAJ",
                        color = CheckpointGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(CheckpointGold.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}
