package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GeometryQuestionBank
import com.example.model.ActiveModal
import com.example.ui.components.AudiencePollModal
import com.example.ui.components.GameOverDialog
import com.example.ui.components.GeometryDiagramView
import com.example.ui.components.LifelinesBar
import com.example.ui.components.MoneyLadderDialog
import com.example.ui.components.OptionButton
import com.example.ui.components.PhoneFriendModal
import com.example.ui.components.QuestionContainer
import com.example.ui.components.WalkAwayConfirmModal
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CheckpointGold
import com.example.ui.theme.MillionaireGold
import com.example.ui.theme.MillionaireGoldLight
import com.example.ui.theme.SelectedOrange
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.TextSilver
import com.example.ui.theme.TextWhite
import com.example.viewmodel.QuizViewModel

@Composable
fun QuizScreen(
    viewModel: QuizViewModel,
    onNavigateBack: () -> Unit,
    onOpenGuide: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    BackHandler {
        if (uiState.activeModal != ActiveModal.NONE) {
            viewModel.dismissModal()
        } else if (!uiState.isGameOver) {
            viewModel.openWalkAwayModal()
        } else {
            onNavigateBack()
        }
    }

    val currentStep = GeometryQuestionBank.prizeLadder.firstOrNull { it.level == uiState.currentLevel }
    val prizeAmountText = currentStep?.displayAmount ?: ""

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF0F1B3E),
                        StudioNavyDark,
                        Color(0xFF03060E)
                    )
                )
            )
            .testTag("quiz_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (!uiState.isGameOver) viewModel.openWalkAwayModal() else onNavigateBack()
                    },
                    modifier = Modifier.testTag("btn_quiz_back")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Geri / Çekil",
                        tint = TextSilver
                    )
                }

                // Question & Level badge
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "SORU ${uiState.currentLevel} / 12",
                        color = MillionaireGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (uiState.currentLevel == 12) "500 MİLYAR ÖDÜLÜ" else prizeAmountText,
                        color = MillionaireGoldLight,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // Guaranteed Checkpoint Indicator
                if (uiState.guaranteedAmount > 0) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(CheckpointGold.copy(alpha = 0.15f))
                            .border(1.dp, CheckpointGold, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = CheckpointGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${uiState.guaranteedAmount} TL",
                            color = CheckpointGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(48.dp))
                }
            }

            // Lifelines Bar
            LifelinesBar(
                lifelines = uiState.lifelines,
                onFiftyFifty = { viewModel.useFiftyFifty() },
                onPhoneFriend = { viewModel.openPhoneFriendModal() },
                onAskAudience = { viewModel.useAskAudience() },
                onSwapQuestion = { viewModel.useSwapQuestion() },
                onOpenLadder = { viewModel.openLadderModal() },
                onWalkAway = { viewModel.openWalkAwayModal() },
                enabled = !uiState.answerLocked && !uiState.isGameOver,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Question Container
            val currentQ = uiState.currentQuestion
            if (currentQ != null) {
                QuestionContainer(
                    level = uiState.currentLevel,
                    prizeAmount = prizeAmountText,
                    questionText = currentQ.questionText,
                    modifier = Modifier.fillMaxWidth()
                )

                // Geometric Canvas Diagram (if present)
                if (currentQ.diagramData != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        GeometryDiagramView(data = currentQ.diagramData)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Options (A, B, C, D)
                val optionLetters = listOf("A", "B", "C", "D")
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    currentQ.options.forEachIndexed { index, optionText ->
                        val letter = optionLetters[index]
                        val status = viewModel.getOptionStatus(index)

                        OptionButton(
                            letter = letter,
                            text = optionText,
                            status = status,
                            onClick = { viewModel.selectOption(index) },
                            enabled = !uiState.answerLocked && !uiState.isGameOver
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // "Son Kararım" (Confirm Answer) Button
                AnimatedVisibility(
                    visible = uiState.selectedOptionIndex != null && !uiState.answerRevealed,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        if (uiState.answerLocked) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .height(52.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(SelectedOrange.copy(alpha = 0.2f))
                                    .border(1.5.dp, SelectedOrange, RoundedCornerShape(14.dp))
                                    .padding(8.dp)
                            ) {
                                CircularProgressIndicator(
                                    color = MillionaireGold,
                                    strokeWidth = 3.dp,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Son Kararınız Alındı...",
                                    color = MillionaireGoldLight,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            Button(
                                onClick = { viewModel.confirmAnswer() },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioAmber),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .height(52.dp)
                                    .border(2.dp, MillionaireGold, RoundedCornerShape(14.dp))
                                    .testTag("btn_confirm_answer")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = StudioNavyDark,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "SON KARARIM",
                                    color = StudioNavyDark,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Modals Overlay
        when (uiState.activeModal) {
            ActiveModal.MONEY_LADDER -> {
                MoneyLadderDialog(
                    currentLevel = uiState.currentLevel,
                    onDismiss = { viewModel.dismissModal() }
                )
            }
            ActiveModal.PHONE_FRIEND_SELECT -> {
                PhoneFriendModal(
                    phoneResponse = null,
                    onSelectFriend = { viewModel.executePhoneCall(it) },
                    onDismiss = { viewModel.dismissModal() }
                )
            }
            ActiveModal.PHONE_FRIEND_RESULT -> {
                PhoneFriendModal(
                    phoneResponse = uiState.phoneResponse,
                    onSelectFriend = {},
                    onDismiss = { viewModel.dismissModal() }
                )
            }
            ActiveModal.AUDIENCE_POLL -> {
                uiState.audienceVoteResult?.let { voteResult ->
                    AudiencePollModal(
                        voteResult = voteResult,
                        onDismiss = { viewModel.dismissModal() }
                    )
                }
            }
            ActiveModal.CONFIRM_WALKAWAY -> {
                val previousLevel = uiState.currentLevel - 1
                val earnedPrize = if (previousLevel >= 1) {
                    GeometryQuestionBank.prizeLadder.firstOrNull { it.level == previousLevel }?.prizeAmount ?: 0L
                } else 0L
                val previousDisplay = if (previousLevel >= 1) {
                    GeometryQuestionBank.prizeLadder.firstOrNull { it.level == previousLevel }?.displayAmount ?: "0 TL"
                } else "0 TL"

                WalkAwayConfirmModal(
                    currentPrize = earnedPrize,
                    displayAmount = previousDisplay,
                    onConfirmWalkAway = { viewModel.confirmWalkAway() },
                    onDismiss = { viewModel.dismissModal() }
                )
            }
            else -> {}
        }

        // Game Over / Victory Modal
        if (uiState.isGameOver) {
            GameOverDialog(
                isVictory = uiState.isVictory,
                walkedAway = uiState.walkedAway,
                wonAmount = uiState.finalPrizeAmount,
                displayAmount = if (uiState.finalPrizeAmount >= 500000) "500.000 TL (500 MİLYAR)" else "${uiState.finalPrizeAmount} TL",
                lastQuestion = uiState.currentQuestion,
                userSelectedOption = uiState.selectedOptionIndex,
                onRestart = { viewModel.startNewGame() },
                onOpenGuide = { onOpenGuide() },
                onGoHome = { onNavigateBack() }
            )
        }
    }
}
