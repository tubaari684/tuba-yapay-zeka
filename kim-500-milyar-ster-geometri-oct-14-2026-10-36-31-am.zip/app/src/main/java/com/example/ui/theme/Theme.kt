package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val QuizGameColorScheme = darkColorScheme(
    primary = MillionaireGold,
    onPrimary = StudioNavyDark,
    primaryContainer = StudioAmber,
    onPrimaryContainer = StudioNavyDark,
    secondary = BorderCyanGlow,
    onSecondary = StudioNavyDark,
    background = StudioNavyDark,
    onBackground = TextWhite,
    surface = StudioNavySurface,
    onSurface = TextWhite,
    surfaceVariant = StudioNavyCard,
    onSurfaceVariant = TextSilver,
    error = WrongRed,
    onError = TextWhite
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = QuizGameColorScheme,
        typography = Typography,
        content = content
    )
}
