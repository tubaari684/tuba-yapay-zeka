package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.CorrectGreenLight
import com.example.ui.theme.MillionaireGold
import com.example.ui.theme.MillionaireGoldLight
import com.example.ui.theme.SelectedOrange
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.TextSilver
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WrongRed

val HexagonChamferShape = GenericShape { size, _ ->
    val chamfer = minOf(size.height * 0.4f, 18f)
    moveTo(chamfer, 0f)
    lineTo(size.width - chamfer, 0f)
    lineTo(size.width, size.height * 0.5f)
    lineTo(size.width - chamfer, size.height)
    lineTo(chamfer, size.height)
    lineTo(0f, size.height * 0.5f)
    close()
}

@Composable
fun QuestionContainer(
    level: Int,
    prizeAmount: String,
    questionText: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(HexagonChamferShape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        StudioNavySurface,
                        StudioNavyDark,
                        StudioNavyCard
                    )
                )
            )
            .border(
                width = 2.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        MillionaireGoldDark,
                        MillionaireGold,
                        BorderCyanGlow,
                        MillionaireGold,
                        MillionaireGoldDark
                    )
                ),
                shape = HexagonChamferShape
            )
            .padding(horizontal = 24.dp, vertical = 18.dp)
            .testTag("question_container")
    ) {
        androidx.compose.foundation.layout.Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Text(
                    text = "SORU $level",
                    color = MillionaireGold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = " • ",
                    color = BorderCyanGlow,
                    fontSize = 13.sp
                )
                Text(
                    text = prizeAmount,
                    color = MillionaireGoldLight,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Text(
                text = questionText,
                color = TextWhite,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                lineHeight = 23.sp
            )
        }
    }
}

private val MillionaireGoldDark = Color(0xFFB45309)

enum class OptionStatus {
    DEFAULT,
    SELECTED,
    CORRECT,
    WRONG,
    ELIMINATED
}

@Composable
fun OptionButton(
    letter: String,
    text: String,
    status: OptionStatus,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    if (status == OptionStatus.ELIMINATED) {
        // 50:50 eliminated option: rendered subtle / empty
        Box(
            modifier = modifier
                .fillMaxWidth()
                .size(height = 56.dp, width = 0.dp)
                .clip(HexagonChamferShape)
                .background(StudioNavyDark.copy(alpha = 0.4f))
                .border(1.dp, Color(0xFF1E293B), HexagonChamferShape)
                .testTag("option_eliminated_$letter")
        )
        return
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val (bgBrush, borderBrush, letterColor) = when (status) {
        OptionStatus.DEFAULT -> Triple(
            Brush.verticalGradient(listOf(StudioNavyCard, StudioNavyDark)),
            Brush.horizontalGradient(listOf(Color(0xFF334155), BorderCyanGlow.copy(alpha = 0.8f), Color(0xFF334155))),
            MillionaireGold
        )
        OptionStatus.SELECTED -> Triple(
            Brush.verticalGradient(
                listOf(
                    SelectedOrange.copy(alpha = 0.85f * pulseAlpha),
                    Color(0xFF9A3412)
                )
            ),
            Brush.horizontalGradient(listOf(MillionaireGoldLight, SelectedOrange, MillionaireGoldLight)),
            TextWhite
        )
        OptionStatus.CORRECT -> Triple(
            Brush.verticalGradient(
                listOf(
                    CorrectGreen.copy(alpha = 0.9f * pulseAlpha),
                    Color(0xFF065F46)
                )
            ),
            Brush.horizontalGradient(listOf(CorrectGreenLight, MillionaireGold, CorrectGreenLight)),
            TextWhite
        )
        OptionStatus.WRONG -> Triple(
            Brush.verticalGradient(
                listOf(
                    WrongRed.copy(alpha = 0.9f),
                    Color(0xFF7F1D1D)
                )
            ),
            Brush.horizontalGradient(listOf(WrongRed, Color(0xFFFCA5A5), WrongRed)),
            TextWhite
        )
        OptionStatus.ELIMINATED -> Triple(
            Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent)),
            Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent)),
            Color.Transparent
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(HexagonChamferShape)
            .background(bgBrush)
            .border(2.dp, borderBrush, HexagonChamferShape)
            .clickable(enabled = enabled && status == OptionStatus.DEFAULT) { onClick() }
            .padding(horizontal = 20.dp, vertical = 13.dp)
            .testTag("option_button_$letter")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Letter Indicator (A:, B:, C:, D:)
            Text(
                text = "$letter:",
                color = letterColor,
                fontSize = 17.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Option Content
            Text(
                text = text,
                color = if (status == OptionStatus.DEFAULT) TextWhite else TextWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 2
            )
        }
    }
}
