package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LifelinesState
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.MillionaireGold
import com.example.ui.theme.MillionaireGoldLight
import com.example.ui.theme.SelectedOrange
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSilver
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WrongRed

@Composable
fun LifelinesBar(
    lifelines: LifelinesState,
    onFiftyFifty: () -> Unit,
    onPhoneFriend: () -> Unit,
    onAskAudience: () -> Unit,
    onSwapQuestion: () -> Unit,
    onOpenLadder: () -> Unit,
    onWalkAway: () -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Joker 1: %50
        LifelineCircularButton(
            label = "%50",
            icon = null,
            textIcon = "%50",
            used = lifelines.fiftyFiftyUsed,
            enabled = enabled && !lifelines.fiftyFiftyUsed,
            onClick = onFiftyFifty,
            tag = "lifeline_fifty_fifty"
        )

        // Joker 2: Telefon
        LifelineCircularButton(
            label = "Telefon",
            icon = Icons.Default.Call,
            used = lifelines.phoneFriendUsed,
            enabled = enabled && !lifelines.phoneFriendUsed,
            onClick = onPhoneFriend,
            tag = "lifeline_phone"
        )

        // Joker 3: Seyirci
        LifelineCircularButton(
            label = "Seyirci",
            icon = Icons.Default.Group,
            used = lifelines.askAudienceUsed,
            enabled = enabled && !lifelines.askAudienceUsed,
            onClick = onAskAudience,
            tag = "lifeline_audience"
        )

        // Joker 4: Soru Değiştir
        LifelineCircularButton(
            label = "Değiştir",
            icon = Icons.Default.SwapHoriz,
            used = lifelines.swapQuestionUsed,
            enabled = enabled && !lifelines.swapQuestionUsed,
            onClick = onSwapQuestion,
            tag = "lifeline_swap"
        )

        // Para Ağacı / Ladder View
        ActionButton(
            label = "Ağaç",
            icon = Icons.Default.FormatListNumbered,
            color = BorderCyanGlow,
            onClick = onOpenLadder,
            tag = "btn_show_ladder"
        )

        // Çekil / Walk Away
        ActionButton(
            label = "Çekil",
            icon = Icons.Default.Logout,
            color = StudioAmber,
            onClick = onWalkAway,
            enabled = enabled,
            tag = "btn_walkaway"
        )
    }
}

@Composable
fun LifelineCircularButton(
    label: String,
    icon: ImageVector? = null,
    textIcon: String? = null,
    used: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(
                    if (used) Brush.verticalGradient(listOf(StudioNavyDark.copy(alpha = 0.5f), StudioNavyDark.copy(alpha = 0.5f)))
                    else Brush.verticalGradient(listOf(StudioNavyCard, StudioNavyDark))
                )
                .border(
                    width = 2.dp,
                    color = if (used) TextMuted.copy(alpha = 0.4f)
                    else if (enabled) MillionaireGold
                    else BorderCyanGlow.copy(alpha = 0.5f),
                    shape = CircleShape
                )
                .clickable(enabled = enabled && !used) { onClick() }
                .testTag(tag),
            contentAlignment = Alignment.Center
        ) {
            if (used) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "$label Kullanıldı",
                    tint = WrongRed.copy(alpha = 0.7f),
                    modifier = Modifier.size(24.dp)
                )
            } else if (textIcon != null) {
                Text(
                    text = textIcon,
                    color = if (enabled) MillionaireGoldLight else TextMuted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black
                )
            } else if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (enabled) MillionaireGoldLight else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        Text(
            text = label,
            color = if (used) TextMuted else TextSilver,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
fun ActionButton(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    enabled: Boolean = true,
    tag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(StudioNavyCard.copy(alpha = 0.8f))
                .border(1.5.dp, if (enabled) color else TextMuted, RoundedCornerShape(12.dp))
                .clickable(enabled = enabled) { onClick() }
                .testTag(tag),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (enabled) color else TextMuted,
                modifier = Modifier.size(20.dp)
            )
        }
        Text(
            text = label,
            color = if (enabled) color else TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}
