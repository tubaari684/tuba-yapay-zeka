package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.GameStats
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CheckpointGold
import com.example.ui.theme.MillionaireGold
import com.example.ui.theme.MillionaireGoldLight
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSilver
import com.example.ui.theme.TextWhite

@Composable
fun StartScreen(
    stats: GameStats,
    onStartGame: () -> Unit,
    onOpenGuide: () -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onToggleVibration: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var showRulesDialog by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF13224E),
                        StudioNavyDark,
                        Color(0xFF040711)
                    )
                )
            )
            .padding(horizontal = 20.dp)
            .testTag("start_screen")
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(vertical = 24.dp)
        ) {
            // Sound and Vibration toggles at top right
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(
                    onClick = { onToggleSound(!stats.soundEnabled) },
                    modifier = Modifier.testTag("btn_toggle_sound")
                ) {
                    Icon(
                        imageVector = if (stats.soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                        contentDescription = "Ses",
                        tint = if (stats.soundEnabled) MillionaireGold else TextMuted
                    )
                }
                IconButton(
                    onClick = { onToggleVibration(!stats.vibrationEnabled) },
                    modifier = Modifier.testTag("btn_toggle_vibrate")
                ) {
                    Icon(
                        imageVector = Icons.Default.Vibration,
                        contentDescription = "Titreşim",
                        tint = if (stats.vibrationEnabled) MillionaireGold else TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Logo Medallion
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(MillionaireGold.copy(alpha = 0.3f), Color.Transparent)
                        )
                    )
                    .border(3.dp, MillionaireGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_quiz_geometry_1791962497568),
                    contentDescription = "Oyun Logosu",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Show Title
            Text(
                text = "KİM 500 MİLYAR İSTER?",
                color = MillionaireGold,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center
            )

            Text(
                text = "5. Sınıf Temel Geometri Yarışması",
                color = BorderCyanGlow,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )

            Text(
                text = "Nokta, Doğru, Işın, Açılar ve Üçgenler",
                color = TextSilver,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // High Score / Stats Summary Card
            Card(
                colors = CardDefaults.cardColors(containerColor = StudioNavyCard.copy(alpha = 0.85f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, BorderCyanGlow.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("En Yüksek Ödül", color = TextSilver, fontSize = 11.sp)
                        Text(
                            text = if (stats.highestPrize > 0) "${stats.highestPrize} TL" else "0 TL",
                            color = MillionaireGoldLight,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(30.dp)
                            .background(Color(0xFF334155))
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Oyun Sayısı", color = TextSilver, fontSize = 11.sp)
                        Text(
                            text = "${stats.gamesPlayed}",
                            color = TextWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(30.dp)
                            .background(Color(0xFF334155))
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Şampiyonluk", color = TextSilver, fontSize = 11.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = CheckpointGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${stats.millionaireWins}",
                                color = CheckpointGold,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Primary Start Button
            Button(
                onClick = onStartGame,
                colors = ButtonDefaults.buttonColors(
                    containerColor = StudioAmber
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .border(2.dp, MillionaireGoldLight, RoundedCornerShape(16.dp))
                    .testTag("btn_start_game")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = StudioNavyDark,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "YARIŞMAYA BAŞLA",
                    color = StudioNavyDark,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Geometry Guide Button
            OutlinedButton(
                onClick = onOpenGuide,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_open_guide")
            ) {
                Icon(
                    imageVector = Icons.Default.AutoStories,
                    contentDescription = null,
                    tint = BorderCyanGlow,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "5. Sınıf Geometri Rehberi",
                    color = TextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Rules Button
            OutlinedButton(
                onClick = { showRulesDialog = true },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_open_rules")
            ) {
                Icon(
                    imageVector = Icons.Default.HelpOutline,
                    contentDescription = null,
                    tint = TextSilver,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Nasıl Oynanır & Jokerler",
                    color = TextSilver,
                    fontSize = 14.sp
                )
            }
        }
    }

    if (showRulesDialog) {
        RulesDialog(onDismiss = { showRulesDialog = false })
    }
}

@Composable
fun RulesDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(StudioNavySurface)
                .border(1.5.dp, MillionaireGold, RoundedCornerShape(20.dp))
                .padding(20.dp)
                .testTag("dialog_rules")
        ) {
            Column {
                Text(
                    text = "YARIŞMA KURALLARI",
                    color = MillionaireGold,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Text(
                    text = "• Toplam 12 soru bulunmaktadır.\n" +
                            "• 2. Soru (1.000 TL) ve 7. Soru (15.000 TL) BARAJ sorularıdır. Bu soruları geçtikten sonra elenseniz bile baraj ödülünü kazanırsınız.\n" +
                            "• 12. Soruyu bilirseniz 500.000 TL (500 Milyar) BÜYÜK ÖDÜLÜ kazanırsınız!\n\n" +
                            "JOKER HAKLARI:\n" +
                            "1. %50: İki yanlış şıkkı siler.\n" +
                            "2. Telefon Jokeri: Öğretmen, öğrenci veya mühendisi arayıp fikrini sorabilirsiniz.\n" +
                            "3. Seyirci Jokeri: Stüdyodaki 100 seyircinin oy dağılım grafiğini gösterir.\n" +
                            "4. Soru Değiştir: Soruyu aynı para değerindeki yeni bir soruyla değiştirir.\n\n" +
                            "• İstediğiniz soruda 'Çekil' butonuna basarak kazandığınız ödülü alıp ayrılabilirsiniz.",
                    color = TextSilver,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioAmber),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_rules_close")
                ) {
                    Text("Anladım", color = StudioNavyDark, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
