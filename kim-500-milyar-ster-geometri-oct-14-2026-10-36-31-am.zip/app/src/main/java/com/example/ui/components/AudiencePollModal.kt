package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.AudienceVoteResult
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.MillionaireGold
import com.example.ui.theme.MillionaireGoldLight
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.TextSilver
import com.example.ui.theme.TextWhite

@Composable
fun AudiencePollModal(
    voteResult: AudienceVoteResult,
    onDismiss: () -> Unit
) {
    var animated by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        animated = true
    }

    val letters = listOf("A", "B", "C", "D")
    val maxVote = voteResult.percentages.maxOrNull() ?: 100

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(StudioNavySurface, StudioNavyDark)
                    )
                )
                .border(2.dp, BorderCyanGlow, RoundedCornerShape(20.dp))
                .padding(20.dp)
                .testTag("dialog_audience_poll")
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Groups,
                            contentDescription = "Seyirci Jokeri",
                            tint = MillionaireGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SEYİRCİ OYLAMASI",
                            color = MillionaireGold,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("btn_close_audience")) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat", tint = TextSilver)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Stüdyodaki 100 seyircinin verdiği oyların dağılımı:",
                    color = TextSilver,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Vertical Bar Chart
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(StudioNavyCard.copy(alpha = 0.6f))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    voteResult.percentages.forEachIndexed { index, pct ->
                        val letter = letters.getOrElse(index) { "?" }
                        val isLeading = pct == maxVote

                        val animProgress by animateFloatAsState(
                            targetValue = if (animated) pct / 100f else 0f,
                            animationSpec = tween(700, delayMillis = index * 80),
                            label = "bar_$index"
                        )

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            // Percentage Label
                            Text(
                                text = "%$pct",
                                color = if (isLeading) MillionaireGoldLight else TextSilver,
                                fontSize = 12.sp,
                                fontWeight = if (isLeading) FontWeight.Black else FontWeight.SemiBold
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // Vertical bar
                            Box(
                                modifier = Modifier
                                    .width(38.dp)
                                    .height((110 * animProgress).dp.coerceAtLeast(4.dp))
                                    .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                    .background(
                                        if (isLeading) Brush.verticalGradient(
                                            listOf(MillionaireGoldLight, StudioAmber)
                                        )
                                        else Brush.verticalGradient(
                                            listOf(BorderCyanGlow.copy(alpha = 0.8f), Color(0xFF1E3A8A))
                                        )
                                    )
                                    .border(
                                        1.dp,
                                        if (isLeading) MillionaireGold else BorderCyanGlow.copy(alpha = 0.4f),
                                        RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)
                                    )
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Option letter
                            Text(
                                text = letter,
                                color = if (isLeading) MillionaireGold else TextWhite,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioAmber),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_audience_done")
                ) {
                    Text("Cevabını Seç", color = StudioNavyDark, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
