package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.PhoneFriendCharacter
import com.example.model.PhoneResponse
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.MillionaireGold
import com.example.ui.theme.MillionaireGoldLight
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSilver
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.delay

@Composable
fun PhoneFriendModal(
    phoneResponse: PhoneResponse?,
    onSelectFriend: (PhoneFriendCharacter) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(StudioNavySurface, StudioNavyDark)
                    )
                )
                .border(2.dp, BorderCyanGlow, RoundedCornerShape(20.dp))
                .padding(20.dp)
                .testTag("dialog_phone_friend")
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Telefon Jokeri",
                            tint = MillionaireGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TELEFON JOKERİ",
                            color = MillionaireGold,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("btn_close_phone")) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat", tint = TextSilver)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (phoneResponse == null) {
                    // Step 1: Select person to call
                    Text(
                        text = "Kimi aramak istiyorsun?",
                        color = TextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    PhoneFriendCharacter.values().forEach { friend ->
                        FriendSelectionCard(
                            friend = friend,
                            onSelect = { onSelectFriend(friend) }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                } else {
                    // Step 2: Friend has responded!
                    PhoneCallDialogueView(
                        response = phoneResponse,
                        onClose = onDismiss
                    )
                }
            }
        }
    }
}

@Composable
fun FriendSelectionCard(
    friend: PhoneFriendCharacter,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(StudioNavyCard)
            .border(1.dp, BorderCyanGlow.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .clickable { onSelect() }
            .padding(12.dp)
            .testTag("friend_card_${friend.name}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(StudioAmber.copy(alpha = 0.2f))
                    .border(1.dp, MillionaireGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (friend) {
                        PhoneFriendCharacter.MATH_TEACHER -> Icons.Default.School
                        PhoneFriendCharacter.HONOR_STUDENT -> Icons.Default.Star
                        PhoneFriendCharacter.ENGINEER_UNCLE -> Icons.Default.Person
                    },
                    contentDescription = null,
                    tint = MillionaireGold,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = friend.personName,
                    color = TextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = friend.title,
                    color = MillionaireGoldLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = friend.description,
                    color = TextSilver,
                    fontSize = 11.sp,
                    lineHeight = 14.sp
                )
            }

            Icon(
                imageVector = Icons.Default.Call,
                contentDescription = "Ara",
                tint = CorrectGreen,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun PhoneCallDialogueView(
    response: PhoneResponse,
    onClose: () -> Unit
) {
    val optionLetters = listOf("A", "B", "C", "D")
    val letter = optionLetters.getOrElse(response.suggestedOptionIndex) { "A" }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        // Friend avatar and name
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(StudioAmber.copy(alpha = 0.25f))
                .border(2.dp, MillionaireGold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = when (response.character) {
                    PhoneFriendCharacter.MATH_TEACHER -> Icons.Default.School
                    PhoneFriendCharacter.HONOR_STUDENT -> Icons.Default.Star
                    PhoneFriendCharacter.ENGINEER_UNCLE -> Icons.Default.Person
                },
                contentDescription = null,
                tint = MillionaireGold,
                modifier = Modifier.size(34.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "${response.character.personName} hatta!",
            color = MillionaireGoldLight,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Dialogue speech bubble
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(StudioNavyCard)
                .border(1.dp, BorderCyanGlow, RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Text(
                text = "💬 \"${response.message}\"",
                color = TextWhite,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                textAlign = TextAlign.Start
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Suggested answer badge
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(StudioAmber.copy(alpha = 0.15f))
                .border(1.5.dp, MillionaireGold, RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Text(
                text = "Önerilen Şık: ",
                color = TextSilver,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "$letter ŞIKKI",
                color = MillionaireGoldLight,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Confidence bar
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Güven Oranı",
                    color = TextSilver,
                    fontSize = 12.sp
                )
                Text(
                    text = "%${response.confidencePercent}",
                    color = CorrectGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { response.confidencePercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = CorrectGreen,
                trackColor = StudioNavyCard
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onClose,
            colors = ButtonDefaults.buttonColors(containerColor = StudioAmber),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("btn_phone_done")
        ) {
            Text("Teşekkür Et ve Kapat", color = StudioNavyDark, fontWeight = FontWeight.Bold)
        }
    }
}
