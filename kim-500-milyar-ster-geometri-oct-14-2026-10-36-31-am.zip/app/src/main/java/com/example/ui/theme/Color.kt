package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Game Show Studio Midnight Theme
val StudioNavyDark = Color(0xFF070B19)
val StudioNavyMedium = Color(0xFF0F1A3A)
val StudioNavySurface = Color(0xFF16254F)
val StudioNavyCard = Color(0xFF1C2E63)

// Gold & Accent Highlights
val MillionaireGold = Color(0xFFFFD700)
val MillionaireGoldLight = Color(0xFFFDE047)
val MillionaireGoldDark = Color(0xFFB45309)
val StudioAmber = Color(0xFFF59E0B)

// Game State Colors
val CorrectGreen = Color(0xFF10B981)
val CorrectGreenLight = Color(0xFF34D399)
val WrongRed = Color(0xFFEF4444)
val SelectedOrange = Color(0xFFF97316)
val CheckpointGold = Color(0xFFFBBF24)

// Neutral & Text Colors
val TextWhite = Color(0xFFFFFFFF)
val TextSilver = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF94A3B8)
val BorderCyanGlow = Color(0xFF38BDF8)
