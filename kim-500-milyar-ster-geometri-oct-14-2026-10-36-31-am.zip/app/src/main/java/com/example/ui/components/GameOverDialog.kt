package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SentimentDissatisfied
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.Question
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CheckpointGold
import com.example.ui.theme.CorrectGreen
import com.example.ui.theme.MillionaireGold
import com.example.ui.theme.MillionaireGoldLight
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioNavyCard
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.StudioNavySurface
import com.example.ui.theme.TextSilver
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WrongRed

@Composable
fun GameOverDialog(
    isVictory: Boolean,
    walkedAway: Boolean,
    wonAmount: Long,
    displayAmount: String,
    lastQuestion: Question?,
    userSelectedOption: Int?,
    onRestart: () -> Unit,
    onOpenGuide: () -> Unit,
    onGoHome: () -> Unit
) {
    val scrollState = rememberScrollState()

    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(StudioNavySurface, StudioNavyDark)
                    )
                )
                .border(
                    2.dp,
                    if (isVictory) MillionaireGold else if (walkedAway) StudioAmber else BorderCyanGlow,
                    RoundedCornerShape(24.dp)
                )
                .padding(20.dp)
                .testTag("dialog_game_over")
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
            ) {
                // Top Celebration Icon
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(
                            if (isVictory) MillionaireGold.copy(alpha = 0.2f)
                            else if (walkedAway) StudioAmber.copy(alpha = 0.2f)
                            else WrongRed.copy(alpha = 0.2f)
                        )
                        .border(
                            2.dp,
                            if (isVictory) MillionaireGold else if (walkedAway) StudioAmber else WrongRed,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isVictory) Icons.Default.EmojiEvents
                        else if (walkedAway) Icons.Default.EmojiEvents
                        else Icons.Default.SentimentDissatisfied,
                        contentDescription = null,
                        tint = if (isVictory) MillionaireGoldLight else if (walkedAway) StudioAmber else WrongRed,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Title
                Text(
                    text = when {
                        isVictory -> "TEBRİKLER ŞAMPİYON! 🏆"
                        walkedAway -> "KAZANÇLA AYRILDINIZ!"
                        else -> "YARIŞMA SONA ERDİ"
                    },
                    color = if (isVictory) MillionaireGold else TextWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = when {
                        isVictory -> "Tüm soruları bilerek 500 Milyar büyük ödülün sahibi oldunuz!"
                        walkedAway -> "Akıllıca bir kararla çekilerek ödülünüzü cebinize koydunuz."
                        wonAmount > 0 -> "Barajı geçtiğiniz için garanti ödülünüzü kazandınız."
                        else -> "İlk barajı geçemediğiniz için ödülsüz ayrılıyorsunuz."
                    },
                    color = TextSilver,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )

                // Prize Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(StudioNavyCard, StudioNavySurface, StudioNavyCard)
                            )
                        )
                        .border(1.5.dp, MillionaireGold, RoundedCornerShape(14.dp))
                        .padding(vertical = 12.dp, horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "KAZANDIĞINIZ ÖDÜL",
                            color = CheckpointGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = displayAmount,
                            color = MillionaireGoldLight,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Educational Solution Card
                if (lastQuestion != null) {
                    val letters = listOf("A", "B", "C", "D")
                    val correctLetter = letters.getOrElse(lastQuestion.correctIndex) { "" }
                    val userLetter = if (userSelectedOption != null) letters.getOrElse(userSelectedOption) { "" } else null

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(StudioNavyCard)
                            .border(1.dp, BorderCyanGlow.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = BorderCyanGlow,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "GEOMETRİK ÇÖZÜM REHBERİ",
                                    color = BorderCyanGlow,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Doğru Cevap: $correctLetter) ${lastQuestion.options.getOrElse(lastQuestion.correctIndex) { "" }}",
                                color = CorrectGreen,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )

                            if (userLetter != null && userSelectedOption != lastQuestion.correctIndex) {
                                val userOptText = userSelectedOption?.let { lastQuestion.options.getOrNull(it) } ?: ""
                                Text(
                                    text = "Sizin Cevabınız: $userLetter) $userOptText",
                                    color = WrongRed,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = lastQuestion.explanation,
                                color = TextSilver,
                                fontSize = 12.sp,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Action Buttons
                Button(
                    onClick = onRestart,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioAmber),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_gameover_restart")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = StudioNavyDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Yeni Yarışmaya Başla", color = StudioNavyDark, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onOpenGuide,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_gameover_guide")
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoStories,
                        contentDescription = null,
                        tint = BorderCyanGlow,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Geometri Konusunu Çalış", color = TextWhite)
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedButton(
                    onClick = onGoHome,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_gameover_home")
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = null,
                        tint = TextSilver,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Ana Menüye Dön", color = TextSilver)
                }
            }
        }
    }
}
