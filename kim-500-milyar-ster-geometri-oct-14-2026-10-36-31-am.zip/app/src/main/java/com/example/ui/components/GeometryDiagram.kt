package com.example.ui.components

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import com.example.model.DiagramData
import com.example.model.DiagramType
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.MillionaireGold
import com.example.ui.theme.MillionaireGoldLight
import com.example.ui.theme.StudioNavyDark
import com.example.ui.theme.TextWhite
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GeometryDiagramView(
    data: DiagramData,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .width(280.dp)
            .height(130.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(StudioNavyDark.copy(alpha = 0.85f))
            .border(1.dp, BorderCyanGlow.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val primaryColor = MillionaireGold
            val secondaryColor = BorderCyanGlow
            val accentColor = TextWhite

            val textPaint = Paint().apply {
                color = android.graphics.Color.WHITE
                textSize = 34f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }
            val goldPaint = Paint().apply {
                color = android.graphics.Color.parseColor("#FFD700")
                textSize = 32f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
                typeface = android.graphics.Typeface.DEFAULT_BOLD
            }

            when (data.type) {
                DiagramType.LINE -> {
                    // Line with two arrows
                    val y = height / 2
                    val startX = 35f
                    val endX = width - 35f

                    // Draw main line
                    drawLine(
                        color = primaryColor,
                        start = Offset(startX, y),
                        end = Offset(endX, y),
                        strokeWidth = 5f,
                        cap = StrokeCap.Round
                    )
                    // Left arrow
                    val leftArrow = Path().apply {
                        moveTo(startX, y)
                        lineTo(startX + 18f, y - 12f)
                        moveTo(startX, y)
                        lineTo(startX + 18f, y + 12f)
                    }
                    drawPath(leftArrow, primaryColor, style = Stroke(width = 4f, cap = StrokeCap.Round))

                    // Right arrow
                    val rightArrow = Path().apply {
                        moveTo(endX, y)
                        lineTo(endX - 18f, y - 12f)
                        moveTo(endX, y)
                        lineTo(endX - 18f, y + 12f)
                    }
                    drawPath(rightArrow, primaryColor, style = Stroke(width = 4f, cap = StrokeCap.Round))

                    // Points A and B
                    val ptAX = width * 0.35f
                    val ptBX = width * 0.65f
                    drawCircle(accentColor, radius = 7f, center = Offset(ptAX, y))
                    drawCircle(accentColor, radius = 7f, center = Offset(ptBX, y))

                    drawContext.canvas.nativeCanvas.drawText("A", ptAX, y - 15f, textPaint)
                    drawContext.canvas.nativeCanvas.drawText("B", ptBX, y - 15f, textPaint)
                    drawContext.canvas.nativeCanvas.drawText("d doğrusu (AB)", width / 2, height - 10f, goldPaint)
                }

                DiagramType.RAY -> {
                    // Ray: starting endpoint A, arrow at B
                    val y = height / 2
                    val startX = 50f
                    val endX = width - 40f

                    drawLine(
                        color = secondaryColor,
                        start = Offset(startX, y),
                        end = Offset(endX, y),
                        strokeWidth = 5f,
                        cap = StrokeCap.Round
                    )
                    // Solid start point A
                    drawCircle(MillionaireGoldLight, radius = 9f, center = Offset(startX, y))
                    // Arrow at end
                    val arrow = Path().apply {
                        moveTo(endX, y)
                        lineTo(endX - 18f, y - 12f)
                        moveTo(endX, y)
                        lineTo(endX - 18f, y + 12f)
                    }
                    drawPath(arrow, secondaryColor, style = Stroke(width = 4f, cap = StrokeCap.Round))

                    // Point B on ray
                    val ptBX = width * 0.70f
                    drawCircle(accentColor, radius = 6f, center = Offset(ptBX, y))

                    drawContext.canvas.nativeCanvas.drawText("A (Başlangıç)", startX + 25f, y - 16f, goldPaint)
                    drawContext.canvas.nativeCanvas.drawText("B", ptBX, y - 16f, textPaint)
                    drawContext.canvas.nativeCanvas.drawText("[AB) Işını", width / 2, height - 10f, textPaint)
                }

                DiagramType.LINE_SEGMENT -> {
                    // Segment: closed at both A and B
                    val y = height / 2
                    val startX = 60f
                    val endX = width - 60f

                    drawLine(
                        color = primaryColor,
                        start = Offset(startX, y),
                        end = Offset(endX, y),
                        strokeWidth = 6f,
                        cap = StrokeCap.Round
                    )
                    drawCircle(MillionaireGoldLight, radius = 9f, center = Offset(startX, y))
                    drawCircle(MillionaireGoldLight, radius = 9f, center = Offset(endX, y))

                    drawContext.canvas.nativeCanvas.drawText("K", startX, y - 15f, textPaint)
                    drawContext.canvas.nativeCanvas.drawText("L", endX, y - 15f, textPaint)
                    drawContext.canvas.nativeCanvas.drawText("[KL] Doğru Parçası", width / 2, height - 10f, goldPaint)
                }

                DiagramType.PARALLEL_LINES -> {
                    // Two parallel lines
                    val y1 = height * 0.32f
                    val y2 = height * 0.68f
                    val startX = 40f
                    val endX = width - 40f

                    drawLine(primaryColor, Offset(startX, y1), Offset(endX, y1), strokeWidth = 4f)
                    drawLine(primaryColor, Offset(startX, y2), Offset(endX, y2), strokeWidth = 4f)

                    drawContext.canvas.nativeCanvas.drawText("d", startX - 18f, y1 + 8f, goldPaint)
                    drawContext.canvas.nativeCanvas.drawText("k", startX - 18f, y2 + 8f, goldPaint)
                    drawContext.canvas.nativeCanvas.drawText("d // k (Paralel)", width / 2, height - 10f, textPaint)
                }

                DiagramType.PERPENDICULAR_LINES -> {
                    // Perpendicular lines with square right-angle symbol
                    val midX = width / 2
                    val midY = height / 2

                    drawLine(secondaryColor, Offset(midX, 15f), Offset(midX, height - 20f), strokeWidth = 4f)
                    drawLine(secondaryColor, Offset(40f, midY), Offset(width - 40f, midY), strokeWidth = 4f)

                    // Right angle marker
                    val markerSize = 20f
                    val rightAnglePath = Path().apply {
                        moveTo(midX + markerSize, midY)
                        lineTo(midX + markerSize, midY - markerSize)
                        lineTo(midX, midY - markerSize)
                    }
                    drawPath(rightAnglePath, primaryColor, style = Stroke(width = 3f))
                    drawCircle(primaryColor, radius = 3f, center = Offset(midX + markerSize / 2, midY - markerSize / 2))

                    drawContext.canvas.nativeCanvas.drawText("90° (Dik açı)", width * 0.75f, height * 0.35f, goldPaint)
                    drawContext.canvas.nativeCanvas.drawText("AB ⊥ CD", width / 2, height - 5f, textPaint)
                }

                DiagramType.INTERSECTING_LINES -> {
                    val midX = width / 2
                    val midY = height / 2
                    drawLine(primaryColor, Offset(40f, 20f), Offset(width - 40f, height - 20f), strokeWidth = 4f)
                    drawLine(secondaryColor, Offset(40f, height - 20f), Offset(width - 40f, 20f), strokeWidth = 4f)
                    drawCircle(accentColor, radius = 7f, center = Offset(midX, midY))
                    drawContext.canvas.nativeCanvas.drawText("Kesişim Noktası", width / 2, height - 6f, textPaint)
                }

                DiagramType.RIGHT_ANGLE -> {
                    val vertexX = 60f
                    val vertexY = height - 30f
                    val armLength = 80f

                    drawLine(primaryColor, Offset(vertexX, vertexY), Offset(vertexX + armLength + 50f, vertexY), strokeWidth = 5f)
                    drawLine(primaryColor, Offset(vertexX, vertexY), Offset(vertexX, vertexY - armLength), strokeWidth = 5f)

                    // 90 deg corner
                    val boxSize = 22f
                    val boxPath = Path().apply {
                        moveTo(vertexX + boxSize, vertexY)
                        lineTo(vertexX + boxSize, vertexY - boxSize)
                        lineTo(vertexX, vertexY - boxSize)
                    }
                    drawPath(boxPath, secondaryColor, style = Stroke(width = 3f))
                    drawCircle(secondaryColor, radius = 3.5f, center = Offset(vertexX + boxSize / 2, vertexY - boxSize / 2))

                    drawContext.canvas.nativeCanvas.drawText("B (Köşe)", vertexX - 10f, vertexY + 22f, textPaint)
                    drawContext.canvas.nativeCanvas.drawText("s(B) = 90° (DİK AÇI)", width * 0.65f, height / 2, goldPaint)
                }

                DiagramType.ACUTE_ANGLE -> {
                    val vertexX = 60f
                    val vertexY = height - 30f
                    val baseArmLength = 130f

                    // Base horizontal ray
                    drawLine(primaryColor, Offset(vertexX, vertexY), Offset(vertexX + baseArmLength, vertexY), strokeWidth = 5f)
                    // Slanted ray (approx 45-50 degrees)
                    val rad = Math.toRadians(45.0)
                    val armX = (vertexX + baseArmLength * cos(rad)).toFloat()
                    val armY = (vertexY - baseArmLength * sin(rad)).toFloat()
                    drawLine(primaryColor, Offset(vertexX, vertexY), Offset(armX, armY), strokeWidth = 5f)

                    // Arc
                    drawArc(
                        color = secondaryColor,
                        startAngle = -45f,
                        sweepAngle = 45f,
                        useCenter = false,
                        topLeft = Offset(vertexX - 25f, vertexY - 25f),
                        size = Size(50f, 50f),
                        style = Stroke(width = 3f)
                    )
                    drawContext.canvas.nativeCanvas.drawText("< 90° (DAR AÇI)", width * 0.65f, height / 2, goldPaint)
                }

                DiagramType.OBTUSE_ANGLE -> {
                    val vertexX = width * 0.55f
                    val vertexY = height - 30f
                    val baseArmLength = 110f

                    // Base horizontal ray pointing right
                    drawLine(primaryColor, Offset(vertexX, vertexY), Offset(vertexX + baseArmLength, vertexY), strokeWidth = 5f)
                    // Slanted ray open wider than 90 deg (e.g. 135 deg, going up and left)
                    val rad = Math.toRadians(135.0)
                    val armX = (vertexX + baseArmLength * cos(rad)).toFloat()
                    val armY = (vertexY - baseArmLength * sin(rad)).toFloat()
                    drawLine(primaryColor, Offset(vertexX, vertexY), Offset(armX, armY), strokeWidth = 5f)

                    // Arc
                    drawArc(
                        color = secondaryColor,
                        startAngle = -135f,
                        sweepAngle = 135f,
                        useCenter = false,
                        topLeft = Offset(vertexX - 30f, vertexY - 30f),
                        size = Size(60f, 60f),
                        style = Stroke(width = 3f)
                    )
                    drawContext.canvas.nativeCanvas.drawText("> 90° (GENİŞ AÇI)", width * 0.35f, 25f, goldPaint)
                }

                DiagramType.CLOCK_TIME -> {
                    // Clock face
                    val centerX = width / 2
                    val centerY = height / 2 - 5f
                    val radius = 45f

                    // Dial
                    drawCircle(StudioNavyDark, radius = radius, center = Offset(centerX, centerY))
                    drawCircle(primaryColor, radius = radius, center = Offset(centerX, centerY), style = Stroke(width = 3f))

                    // 12, 3, 6, 9 marks
                    drawCircle(secondaryColor, radius = 3f, center = Offset(centerX, centerY - radius + 8f)) // 12
                    drawCircle(secondaryColor, radius = 3f, center = Offset(centerX + radius - 8f, centerY)) // 3
                    drawCircle(secondaryColor, radius = 3f, center = Offset(centerX, centerY + radius - 8f)) // 6
                    drawCircle(secondaryColor, radius = 3f, center = Offset(centerX - radius + 8f, centerY)) // 9

                    // Minute hand at 12
                    drawLine(accentColor, Offset(centerX, centerY), Offset(centerX, centerY - radius + 12f), strokeWidth = 4f)

                    if (data.clockHour == 3) {
                        // Hour hand at 3
                        drawLine(MillionaireGoldLight, Offset(centerX, centerY), Offset(centerX + radius - 18f, centerY), strokeWidth = 5f)
                        drawContext.canvas.nativeCanvas.drawText("Saat 03:00 (90° Dik)", width / 2, height - 5f, goldPaint)
                    } else if (data.clockHour == 6) {
                        // Hour hand at 6 (180 deg straight angle)
                        drawLine(MillionaireGoldLight, Offset(centerX, centerY), Offset(centerX, centerY + radius - 18f), strokeWidth = 5f)
                        drawContext.canvas.nativeCanvas.drawText("Saat 06:00 (180° Doğru)", width / 2, height - 5f, goldPaint)
                    }
                    drawCircle(primaryColor, radius = 4f, center = Offset(centerX, centerY))
                }

                DiagramType.TRIANGLE_ANGLES -> {
                    // Triangle with angles
                    val ptA = Offset(width / 2, 25f)
                    val ptB = Offset(width * 0.2f, height - 35f)
                    val ptC = Offset(width * 0.8f, height - 35f)

                    val trianglePath = Path().apply {
                        moveTo(ptA.x, ptA.y)
                        lineTo(ptB.x, ptB.y)
                        lineTo(ptC.x, ptC.y)
                        close()
                    }
                    drawPath(trianglePath, primaryColor, style = Stroke(width = 4f))

                    drawContext.canvas.nativeCanvas.drawText("A: ${data.knownAngle1}°", ptA.x, ptA.y - 8f, goldPaint)
                    drawContext.canvas.nativeCanvas.drawText("B: ${data.knownAngle2}°", ptB.x - 10f, ptB.y + 22f, goldPaint)
                    drawContext.canvas.nativeCanvas.drawText("C: ?°", ptC.x + 10f, ptC.y + 22f, textPaint)
                    drawContext.canvas.nativeCanvas.drawText("Açı Toplamı = 180°", width / 2, height - 10f, textPaint)
                }

                else -> {}
            }
        }
    }
}
