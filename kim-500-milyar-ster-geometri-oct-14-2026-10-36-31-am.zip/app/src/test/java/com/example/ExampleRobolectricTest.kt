package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.GeometryQuestionBank
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Kim 500 Milyar", appName)
  }

  @Test
  fun `verify question bank has valid questions for all 12 levels`() {
    assertEquals(12, GeometryQuestionBank.prizeLadder.size)
    for (level in 1..12) {
      val question = GeometryQuestionBank.getRandomQuestionForLevel(level)
      assertNotNull(question)
      assertEquals(level, question.level)
      assertEquals(4, question.options.size)
      assertTrue(question.correctIndex in 0..3)
      assertTrue(question.questionText.isNotBlank())
    }
  }
}
